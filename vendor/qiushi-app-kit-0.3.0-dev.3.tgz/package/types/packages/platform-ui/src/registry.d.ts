import type { PlatformUiExtension } from './index.tsx';
export interface VerifiedUiRegistration {
    readonly appId: string;
    readonly artifactDigest: string;
    readonly routeSegment: string;
    readonly extension: PlatformUiExtension;
}
/**
 * Runtime registry used by the generic host. Entries are supplied from the
 * verified launch bundle; the platform does not import or branch on app IDs.
 */
export declare class PlatformUiRegistry {
    #private;
    register(entry: VerifiedUiRegistration): void;
    resolve(appId: string, artifactDigest: string): VerifiedUiRegistration | undefined;
    clear(): void;
}
