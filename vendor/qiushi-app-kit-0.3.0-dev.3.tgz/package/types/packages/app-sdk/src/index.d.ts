import { type AnySchema } from 'ajv';
export type Json = null | boolean | number | string | Json[] | {
    [key: string]: Json;
};
export type ErrorCode = 'APP_NOT_ENABLED' | 'FORBIDDEN' | 'NOT_FOUND' | 'VALIDATION_FAILED' | 'OUTPUT_INVALID' | 'IDEMPOTENCY_REQUIRED' | 'IDEMPOTENCY_CONFLICT' | 'EXTERNAL_RESULT_UNKNOWN' | 'CANCELLED' | 'INTERNAL_ERROR';
export declare class AppError extends Error {
    readonly code: ErrorCode;
    constructor(code: ErrorCode, message: string);
}
/** Supplied by a trusted provider. This TS interface is NOT an authentication mechanism. */
export interface ExecutionContext {
    readonly tenantId: string;
    readonly actorId: string;
    readonly installationId: string;
    readonly appId: string;
    readonly appVersion: string;
    readonly enabled: boolean;
    readonly permissions: readonly string[];
}
export interface Customer {
    customerId: string;
    displayName: string;
}
export interface Draft {
    id: string;
    customerId: string;
    title: string;
    details: Json;
}
/** Already scoped and authorized by the provider; application code cannot select a tenant. */
export interface BusinessData {
    get<T = BusinessRecord>(logicalName: string, id: string, signal: AbortSignal): Promise<T | undefined>;
    list<T = BusinessRecord>(logicalName: string, signal: AbortSignal): Promise<readonly T[]>;
    create<T = BusinessRecord>(logicalName: string, input: BusinessRecord, operationId: string, signal: AbortSignal): Promise<T>;
}
export type BusinessRecord = {
    [key: string]: Json;
};
export interface ActionExecution {
    readonly operationId: string;
    readonly signal: AbortSignal;
    readonly data: BusinessData;
}
export interface ActionDefinition {
    id: string;
    toolName: string;
    description: string;
    permissions: readonly string[];
    effects: 'none' | 'business-write';
    inputSchema: AnySchema;
    outputSchema: AnySchema;
    execute(input: Json, execution: ActionExecution): Promise<Json>;
}
export interface AppDefinition {
    id: string;
    version: string;
    actions: readonly ActionDefinition[];
}
export type UiPageKind = 'form' | 'table' | 'conversation' | 'mixed';
export interface UiPageDeclaration {
    readonly id: string;
    readonly title: string;
    readonly kind: UiPageKind;
    readonly requiredHostComponents: readonly ('PageHeader' | 'Field' | 'DataTable' | 'ResultPanel' | 'ConversationPanel' | 'PermissionState' | 'ErrorState' | 'LoadingState')[];
}
export interface UiExtensionManifest {
    readonly apiVersion: 'qiushi.ui.v1';
    readonly entry: 'src/client/index.tsx';
    readonly routeSegment: string;
    readonly pages: readonly UiPageDeclaration[];
}
export interface DataDependencyDeclaration {
    readonly logicalName: string;
    readonly contractVersion: string;
    readonly required: boolean;
    readonly operations: readonly ('list' | 'get' | 'create' | 'update')[];
    readonly fields: readonly {
        readonly name: string;
        readonly type: 'string' | 'integer' | 'decimal-string' | 'boolean' | 'date-time';
        readonly required: boolean;
        readonly purposes: readonly ('ui' | 'model' | 'export' | 'external-action')[];
    }[];
    readonly accessMode: 'tenant-shared' | 'delegated-user';
    readonly purposes: readonly ('ui' | 'model' | 'export' | 'external-action')[];
}
/** Public, development-only v2 release descriptor. The platform must revalidate its digest and authorization. */
export interface AppReleaseDescriptorV2 {
    readonly formatVersion: 'qiushi.app-release.v2';
    readonly appId: string;
    readonly version: string;
    readonly stage: 'development';
    readonly archive: string;
    readonly sha256: string;
    readonly runtimeBaseline: string;
    readonly ui: UiExtensionManifest & {
        readonly pageKind: UiPageKind;
        readonly requiredHostComponents: readonly UiPageDeclaration['requiredHostComponents'][number][];
        readonly sha256: string;
    };
    readonly runtime: readonly {
        readonly kind: 'dsh-tool';
        readonly entry: 'src/host.ts';
        readonly sha256: string;
    }[];
    readonly dataDependencies: readonly DataDependencyDeclaration[];
    readonly permissions: readonly {
        readonly actionId: string;
        readonly purposes: readonly ('ui' | 'model' | 'export' | 'external-action')[];
        readonly declaredPermissions?: readonly string[];
    }[];
    readonly productionReady: false;
}
/** Runtime shape check mirroring the frozen control-plane v2 core before a development artifact is emitted. */
export declare function assertAppReleaseDescriptorV2(value: unknown): asserts value is AppReleaseDescriptorV2;
export declare function validateValue(schema: AnySchema, value: unknown, code?: ErrorCode): asserts value is Json;
export declare function defineApp(app: AppDefinition): AppDefinition;
/**
 * In-process contract-test executor only. No durable storage, process isolation,
 * authentication, distributed lock, or exactly-once guarantee is provided here.
 * Production qsBusiness must supply those facilities; never import this from host.ts.
 */
export declare class DevelopmentExecutor {
    private readonly dataFor;
    private readonly operations;
    readonly audit: {
        actionId: string;
        tenantId: string;
        actorId: string;
        status: string;
    }[];
    constructor(dataFor: (context: ExecutionContext, action: ActionDefinition) => BusinessData);
    execute(app: AppDefinition, actionId: string, rawInput: unknown, context: ExecutionContext, options?: {
        idempotencyKey?: string;
        signal?: AbortSignal;
    }): Promise<Json>;
}
