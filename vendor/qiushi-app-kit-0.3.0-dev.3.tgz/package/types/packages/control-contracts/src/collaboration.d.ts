import { type StandardError } from './runtime.ts';
export type CollaborationTaskKind = 'human' | 'application-run';
export type CollaborationTaskStatus = 'pending' | 'claimed' | 'in-progress' | 'waiting' | 'completed' | 'cancelled' | 'failed';
export type CollaborationPriority = 'low' | 'normal' | 'high' | 'urgent';
export type WorkflowTemplate = 'opportunity-to-quote';
export type WorkflowStatus = 'active' | 'waiting' | 'completed' | 'failed' | 'cancelled';
export type WorkflowStepStatus = 'pending' | 'active' | 'completed' | 'blocked' | 'skipped';
export type NotificationKind = 'task-assigned' | 'task-result' | 'workflow-update' | 'run-result' | 'authorization-changed' | 'file-ready';
export type RunStatus = 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled' | 'reconciling';
export type FileVisibility = 'private' | 'workspace' | 'business';
export type FileStatus = 'uploading' | 'available' | 'failed' | 'archived';
export type FileVersionStatus = 'pending' | 'available' | 'failed';
export interface BusinessReference {
    referenceType: string;
    referenceId: string;
    label: string;
    appId?: string;
    installationId?: string;
}
export interface TaskAssignee {
    actorId: string;
    displayName: string;
}
export interface TaskResult {
    status: 'pending' | 'available' | 'not-available';
    summary?: string;
    runId?: string;
}
export interface Task {
    taskId: string;
    tenantId: string;
    workspaceId: string;
    kind: CollaborationTaskKind;
    title: string;
    sourceAppId: string;
    sourceInstallationId?: string;
    businessReference?: BusinessReference;
    assignee?: TaskAssignee;
    dueAt?: string;
    priority: CollaborationPriority;
    status: CollaborationTaskStatus;
    result?: TaskResult;
    createdAt: string;
    updatedAt: string;
    version: number;
}
export interface TaskActivity {
    activityId: string;
    type: 'created' | 'claimed' | 'completed' | 'cancelled' | 'status-changed' | 'comment';
    label: string;
    occurredAt: string;
    actorDisplayName?: string;
}
export interface TaskDetail extends Task {
    activities: readonly TaskActivity[];
}
export interface TaskPage {
    items: readonly Task[];
    nextCursor: string | null;
}
export interface CreateTaskInput {
    kind: CollaborationTaskKind;
    title: string;
    sourceAppId: string;
    sourceInstallationId?: string;
    businessReference?: BusinessReference;
    assigneeActorId?: string;
    dueAt?: string;
    priority: CollaborationPriority;
}
export interface TaskVersionInput {
    expectedVersion: number;
}
export interface CompleteTaskInput extends TaskVersionInput {
    result?: TaskResult;
}
export interface CancelTaskInput extends TaskVersionInput {
    reason: string;
}
export interface WorkflowStep {
    key: string;
    label: string;
    position: number;
    status: WorkflowStepStatus;
    assignee?: TaskAssignee;
}
export interface Workflow {
    workflowId: string;
    tenantId: string;
    workspaceId: string;
    template: WorkflowTemplate;
    title: string;
    status: WorkflowStatus;
    currentStep: WorkflowStep;
    steps: readonly WorkflowStep[];
    businessReferences: readonly BusinessReference[];
    createdAt: string;
    updatedAt: string;
    version: number;
}
export interface WorkflowPage {
    items: readonly Workflow[];
    nextCursor: string | null;
}
export interface CreateWorkflowInput {
    template: WorkflowTemplate;
    title: string;
    businessReference: BusinessReference;
    assigneeActorId?: string;
}
export interface Notification {
    notificationId: string;
    stableKey: string;
    kind: NotificationKind;
    title: string;
    message: string;
    target?: BusinessReference;
    readAt: string | null;
    createdAt: string;
    version: number;
}
export interface NotificationPage {
    items: readonly Notification[];
    nextCursor: string | null;
}
export interface MarkNotificationReadInput {
    expectedVersion: number;
}
export interface MarkNotificationsReadInput {
    items: readonly {
        notificationId: string;
        expectedVersion: number;
    }[];
}
export interface MarkNotificationsReadResult {
    items: readonly Notification[];
}
export interface RunApplication {
    appId: string;
    installationId: string;
    releaseId: string;
}
export interface RunFailure {
    code: string;
    message: string;
    retryable: boolean;
}
export interface RunSummary {
    runId: string;
    tenantId: string;
    workspaceId: string;
    application: RunApplication;
    operationId?: string;
    conversationId?: string;
    status: RunStatus;
    startedAt: string;
    finishedAt?: string;
    durationMs?: number;
    failure?: RunFailure;
    businessReferences: readonly BusinessReference[];
    createdAt: string;
}
export interface RunActivity {
    activityId: string;
    type: 'queued' | 'started' | 'progress' | 'succeeded' | 'failed' | 'cancelled' | 'reconciling';
    label: string;
    occurredAt: string;
}
export interface RunDetail extends RunSummary {
    activities: readonly RunActivity[];
}
export interface RunPage {
    items: readonly RunSummary[];
    nextCursor: string | null;
}
export interface FileVersion {
    versionId: string;
    version: number;
    sizeBytes: number;
    sha256: string;
    status: FileVersionStatus;
    createdAt: string;
    completedAt?: string;
}
export interface FileMetadata {
    fileId: string;
    tenantId: string;
    workspaceId: string;
    fileName: string;
    mediaType: string;
    sizeBytes: number;
    ownerActorId: string;
    visibility: FileVisibility;
    sourceAppId?: string;
    sourceInstallationId?: string;
    businessReference?: BusinessReference;
    status: FileStatus;
    latestVersion: FileVersion;
    versionCount: number;
    createdAt: string;
    updatedAt: string;
}
export interface FileDetail extends FileMetadata {
    versions: readonly FileVersion[];
}
export interface FilePage {
    items: readonly FileMetadata[];
    nextCursor: string | null;
}
export interface CreateUploadIntentInput {
    fileName: string;
    mediaType: string;
    sizeBytes: number;
    sha256: string;
    visibility: FileVisibility;
    sourceAppId?: string;
    sourceInstallationId?: string;
    businessReference?: BusinessReference;
}
export interface UploadIntent {
    fileId: string;
    versionId: string;
    uploadUrl: string;
    uploadMethod: 'PUT';
    expiresAt: string;
    maxBytes: number;
}
export interface CompleteFileInput {
    expectedVersion: number;
    versionId: string;
    sha256: string;
}
export interface DownloadIntentInput {
    versionId?: string;
}
export interface DownloadIntent {
    fileId: string;
    versionId: string;
    downloadUrl: string;
    expiresAt: string;
    fileName: string;
    mediaType: string;
    sizeBytes: number;
}
export interface CollaborationListOptions {
    limit?: number;
    cursor?: string;
    status?: string;
    tenantId?: string;
    workspaceId?: string;
}
export declare function parseCollaborationError(value: unknown): StandardError;
export declare const parseTask: (value: unknown, path?: string) => Task;
export declare function parseTaskDetail(value: unknown): TaskDetail;
export declare const parseTaskPage: (value: unknown) => {
    items: readonly Task[];
    nextCursor: string | null;
};
export declare const parseWorkflow: (value: unknown, path?: string) => Workflow;
export declare const parseWorkflowPage: (value: unknown) => {
    items: readonly Workflow[];
    nextCursor: string | null;
};
export declare const parseNotification: (value: unknown, path?: string) => Notification;
export declare const parseNotificationPage: (value: unknown) => {
    items: readonly Notification[];
    nextCursor: string | null;
};
export declare function parseMarkNotificationsReadResult(value: unknown): MarkNotificationsReadResult;
export declare const parseRunSummary: (value: unknown, path?: string) => RunSummary;
export declare function parseRunDetail(value: unknown): RunDetail;
export declare const parseRunPage: (value: unknown) => {
    items: readonly RunSummary[];
    nextCursor: string | null;
};
export declare const parseFileMetadata: (value: unknown, path?: string) => FileMetadata;
export declare function parseFileDetail(value: unknown): FileDetail;
export declare const parseFilePage: (value: unknown) => {
    items: readonly FileMetadata[];
    nextCursor: string | null;
};
export declare function parseUploadIntent(value: unknown): UploadIntent;
export declare function parseDownloadIntent(value: unknown): DownloadIntent;
export declare function assertCreateTaskInput(input: CreateTaskInput): void;
export declare function assertCreateWorkflowInput(input: CreateWorkflowInput): void;
export declare function assertTaskVersionInput(input: TaskVersionInput): void;
export declare function assertCompleteTaskInput(input: CompleteTaskInput): void;
export declare function assertCancelTaskInput(input: CancelTaskInput): void;
export declare function assertMarkNotificationReadInput(input: MarkNotificationReadInput): void;
export declare function assertMarkNotificationsReadInput(input: MarkNotificationsReadInput): void;
export declare function assertCreateUploadIntentInput(input: CreateUploadIntentInput): void;
export declare function assertCompleteFileInput(input: CompleteFileInput): void;
export declare function assertDownloadIntentInput(input: DownloadIntentInput): void;
export interface CustomerCollaborationApiClient {
    listTasks(tenantId: string, workspaceId: string, options?: CollaborationListOptions): Promise<TaskPage>;
    getTask(tenantId: string, workspaceId: string, taskId: string): Promise<TaskDetail>;
    createTask(tenantId: string, workspaceId: string, input: CreateTaskInput, idempotencyKey: string): Promise<TaskDetail>;
    claimTask(tenantId: string, workspaceId: string, taskId: string, input: TaskVersionInput, idempotencyKey: string): Promise<TaskDetail>;
    completeTask(tenantId: string, workspaceId: string, taskId: string, input: CompleteTaskInput, idempotencyKey: string): Promise<TaskDetail>;
    cancelTask(tenantId: string, workspaceId: string, taskId: string, input: CancelTaskInput, idempotencyKey: string): Promise<TaskDetail>;
    listWorkflows(tenantId: string, workspaceId: string, options?: CollaborationListOptions): Promise<WorkflowPage>;
    createWorkflow(tenantId: string, workspaceId: string, input: CreateWorkflowInput, idempotencyKey: string): Promise<Workflow>;
    getWorkflow(tenantId: string, workspaceId: string, workflowId: string): Promise<Workflow>;
    listNotifications(tenantId: string, options?: CollaborationListOptions): Promise<NotificationPage>;
    markNotificationRead(tenantId: string, notificationId: string, input: MarkNotificationReadInput, idempotencyKey: string): Promise<Notification>;
    markNotificationsRead(tenantId: string, input: MarkNotificationsReadInput, idempotencyKey: string): Promise<MarkNotificationsReadResult>;
    listRuns(tenantId: string, workspaceId: string, options?: CollaborationListOptions): Promise<RunPage>;
    getRun(tenantId: string, workspaceId: string, runId: string): Promise<RunDetail>;
    listFiles(tenantId: string, workspaceId: string, options?: CollaborationListOptions): Promise<FilePage>;
    getFile(tenantId: string, workspaceId: string, fileId: string): Promise<FileDetail>;
    createUploadIntent(tenantId: string, workspaceId: string, input: CreateUploadIntentInput, idempotencyKey: string): Promise<UploadIntent>;
    completeFile(tenantId: string, workspaceId: string, fileId: string, input: CompleteFileInput, idempotencyKey: string): Promise<FileDetail>;
    createDownloadIntent(tenantId: string, workspaceId: string, fileId: string, input: DownloadIntentInput, idempotencyKey: string): Promise<DownloadIntent>;
}
export interface OperationsCollaborationApiClient {
    listTasks(options?: CollaborationListOptions): Promise<TaskPage>;
    getTask(taskId: string): Promise<TaskDetail>;
    listWorkflows(options?: CollaborationListOptions): Promise<WorkflowPage>;
    getWorkflow(workflowId: string): Promise<Workflow>;
    listNotifications(options?: CollaborationListOptions): Promise<NotificationPage>;
    getNotification(notificationId: string): Promise<Notification>;
    markNotificationRead(notificationId: string, input: MarkNotificationReadInput, idempotencyKey: string): Promise<Notification>;
    markNotificationsRead(input: MarkNotificationsReadInput, idempotencyKey: string): Promise<MarkNotificationsReadResult>;
    listRuns(options?: CollaborationListOptions): Promise<RunPage>;
    getRun(runId: string): Promise<RunDetail>;
    listFiles(options?: CollaborationListOptions): Promise<FilePage>;
    getFile(fileId: string): Promise<FileDetail>;
}
export declare function createCustomerCollaborationApiClient(fetchImpl?: typeof fetch): CustomerCollaborationApiClient;
export declare function createOperationsCollaborationApiClient(fetchImpl?: typeof fetch): OperationsCollaborationApiClient;
