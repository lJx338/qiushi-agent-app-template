import { type MatrixRow } from './endpoint-matrix.ts';
import { type OperationFixtureSet } from './fixtures.ts';
export type FixtureLookup = (row: MatrixRow, request: Request) => {
    status: number;
    body?: unknown;
};
export type ResponseValidator = (row: MatrixRow, result: {
    status: number;
    body?: unknown;
}) => void;
/** Deterministic contract-only adapter: validates matrix method/path/headers, never runs business logic. */
export declare function createContractMockAdapter(lookup: FixtureLookup, rows?: readonly Readonly<{
    domain: import("./endpoint-matrix.ts").ContractDomain;
    method: "GET" | "POST" | "PUT" | "PATCH";
    path: string;
    operationId: string;
    clientMethod: string;
    successStatus: number;
    successSchema: string;
    permission: string;
    pagination: boolean;
    csrf: boolean;
    idempotency: boolean;
    cas: "none" | "expectedVersion" | "expectedConfigVersion" | "expectedStateVersion";
}>[], validateResponse?: ResponseValidator): typeof fetch;
/** Adapter backed by the frozen per-operation scenarios, useful for deterministic client tests. */
export declare function createFixtureMockAdapter(state?: keyof OperationFixtureSet, rows?: readonly Readonly<{
    domain: import("./endpoint-matrix.ts").ContractDomain;
    method: "GET" | "POST" | "PUT" | "PATCH";
    path: string;
    operationId: string;
    clientMethod: string;
    successStatus: number;
    successSchema: string;
    permission: string;
    pagination: boolean;
    csrf: boolean;
    idempotency: boolean;
    cas: "none" | "expectedVersion" | "expectedConfigVersion" | "expectedStateVersion";
}>[], validateResponse?: ResponseValidator): typeof fetch;
