import { type OperationsCollaborationApiClient } from './collaboration.ts';
export type OperationsRole = 'ops.access-admin' | 'ops.operator' | 'ops.publisher' | 'ops.support' | 'ops.auditor';
export interface OperationsMe {
    domain: 'operations';
    accountId: string;
    displayName: string;
    roles: readonly OperationsRole[];
    expiresAt: string;
}
export interface OperationsTenant {
    tenantId: string;
    businessCode: string;
    displayName: string;
    lifecycle: 'onboarding' | 'active' | 'paused' | 'closed';
    version: number;
}
export interface OperationsApp {
    appId: string;
    displayName: string;
    category: string;
    summary: string;
    visibility: 'hidden' | 'listed';
    version: number;
}
export interface OperationsInstallation {
    installationId: string;
    tenantId: string;
    workspaceId: string;
    appId: string;
    releaseId: string;
    status: 'configuring' | 'validating' | 'enabled' | 'disabled' | 'needs-attention' | 'upgrading' | 'upgrade-failed';
    configVersion: number;
    authorizationVersion: number;
    canLaunch: boolean;
    unavailableReasons: readonly string[];
}
export interface CreateTenantInput {
    businessCode: string;
    displayName: string;
    workspaceName: string;
    reason: string;
}
export interface CreateAppInput {
    appId: string;
    displayName: string;
    category: string;
    summary: string;
    visibility: 'hidden' | 'listed';
}
export interface PutEntitlementInput {
    status: 'granted' | 'suspended' | 'revoked';
    startsAt: string;
    endsAt: string | null;
    allowedReleaseIds: readonly string[];
    expectedVersion: number;
    reason: string;
}
export interface TenantSummary {
    tenantId: string;
    businessCode: string;
    displayName: string;
    lifecycle: 'onboarding' | 'active' | 'paused' | 'closed';
    workspaceCount: number;
    activeInstallationCount: number;
    pendingInvitationCount: number;
    version: number;
    updatedAt: string;
}
export interface AppSummary {
    appId: string;
    displayName: string;
    category: string;
    summary: string;
    visibility: 'hidden' | 'listed';
    latestVersion?: number;
    releaseState?: string;
    tenantCount: number;
    version: number;
    updatedAt: string;
}
export interface ReleaseSummary {
    releaseId: string;
    appId: string;
    version: number;
    state: string;
    stateVersion?: number;
    artifactDigest: string;
    descriptorDigest: string;
    permissions: readonly string[];
    dependencies: readonly string[];
    sourceId?: string;
    provider?: string;
    repository?: string;
    sourceCommit?: string;
    artifactPath?: string;
    publishedAt?: string;
}
export interface EntitlementSummary {
    tenantId: string;
    appId: string;
    status: 'granted' | 'suspended' | 'revoked';
    startsAt: string;
    endsAt: string | null;
    allowedReleaseIds: readonly string[];
    version: number;
}
export interface AttentionItem {
    id: string;
    type: 'tenant' | 'app' | 'release' | 'installation' | 'member';
    message: string;
}
export interface OperationsOverview {
    generatedAt: string;
    tenantCounts: {
        total: number;
        active: number;
        onboarding: number;
        paused: number;
        closed: number;
    };
    appCounts: {
        total: number;
        listed: number;
        hidden: number;
    };
    releaseCounts: {
        total: number;
        active: number;
        disabled: number;
    };
    attentionItems: readonly AttentionItem[];
}
export interface OperationsApiClient extends OperationsCollaborationApiClient {
    getMe(): Promise<OperationsMe>;
    logout(idempotencyKey: string): Promise<void>;
    getOverview(): Promise<OperationsOverview>;
    listApps(options?: ListOptions): Promise<Page<OperationsApp>>;
    listTenants(options?: ListOptions): Promise<Page<OperationsTenant>>;
    getTenant(tenantId: string): Promise<TenantSummary>;
    listEntitlements(tenantId: string, options?: ListOptions): Promise<Page<EntitlementSummary>>;
    listInstallations(tenantId: string, options?: ListOptions): Promise<Page<OperationsInstallation>>;
    getApp(appId: string): Promise<AppSummary>;
    listReleases(appId: string, options?: ListOptions): Promise<Page<ReleaseSummary>>;
    getRelease(releaseId: string): Promise<ReleaseSummary>;
    getInstallation(installationId: string): Promise<OperationsInstallation>;
    createTenant(input: CreateTenantInput, idempotencyKey: string): Promise<OperationsTenant>;
    createApp(input: CreateAppInput, idempotencyKey: string): Promise<OperationsApp>;
    putEntitlement(tenantId: string, appId: string, input: PutEntitlementInput, idempotencyKey: string): Promise<EntitlementSummary>;
    inviteFirstTenantAdmin(tenantId: string, input: {
        verifiedEmail: string;
        reason: string;
    }, idempotencyKey: string): Promise<{
        inviteId: string;
        claimUrl: string;
        expiresAt: string;
    }>;
    changeTenantState(tenantId: string, input: {
        expectedVersion: number;
        lifecycle: 'active' | 'paused';
        reason: string;
    }, idempotencyKey: string): Promise<OperationsTenant>;
}
export interface ListOptions {
    limit?: number;
    cursor?: string;
}
export interface Page<T> {
    items: readonly T[];
    nextCursor: string | null;
}
export declare function createOperationsApiClient(fetchImpl?: typeof fetch): OperationsApiClient;
export declare const parseOperationsMe: (x: unknown) => OperationsMe;
export declare const parseOperationsOverview: (x: unknown) => OperationsOverview;
export declare const parseOperationsInstallation: (x: unknown) => OperationsInstallation;
export declare const parseOperationsTenant: (x: unknown) => OperationsTenant;
export declare const parseOperationsApp: (x: unknown) => OperationsApp;
export declare const parseOperationsTenantSummary: (x: unknown, p?: string) => TenantSummary;
export declare const parseOperationsAppSummary: (x: unknown) => AppSummary;
export declare const parseOperationsReleaseSummary: (x: unknown) => ReleaseSummary;
export declare const parseOperationsEntitlementSummary: (x: unknown) => EntitlementSummary;
export declare const parseOperationsAppPage: (x: unknown) => Page<OperationsApp>;
export declare const parseOperationsTenantPage: (x: unknown) => Page<OperationsTenant>;
export declare const parseOperationsInstallationPage: (x: unknown) => Page<OperationsInstallation>;
export declare const parseOperationsReleasePage: (x: unknown) => Page<ReleaseSummary>;
export declare const parseOperationsEntitlementPage: (x: unknown) => Page<EntitlementSummary>;
