import type { DataDependencyContract, DataPurpose } from './data-foundation.ts';
import type { PlatformPageKind, PlatformUiExtensionDescriptor } from './ui-extension.ts';
import type { ConversationEvent, ConversationRef } from './conversation.ts';
/** Machine-readable protocol version for the V3 delivery control plane. */
export declare const APP_DELIVERY_PROTOCOL_VERSION: "qiushi.app-delivery.v1";
export type BuildAttemptState = 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
export type BuildFailureCode = 'SOURCE_NOT_FOUND' | 'SOURCE_COMMIT_REQUIRED' | 'PATH_NOT_ALLOWED' | 'SYMLINK_NOT_ALLOWED' | 'FILE_TOO_LARGE' | 'TOO_MANY_FILES' | 'MANIFEST_INVALID' | 'DIGEST_MISMATCH' | 'BUILD_TIMEOUT' | 'BUILD_FAILED' | 'WORKER_RESTARTED';
export interface BuildRequest {
    readonly attemptId?: string;
    readonly releaseId: string;
    readonly appId: string;
    readonly sourceId: string;
    readonly repository: string;
    readonly sourceCommit: string;
    readonly artifactPath: string;
    readonly artifactDigest: string;
    readonly descriptorDigest: string;
    readonly idempotencyKey: string;
    readonly requestedBy: string;
}
export interface RegisterReleaseInput {
    readonly sourceId: string;
    readonly provider: 'github';
    readonly repository: string;
    readonly sourceCommit: string;
    readonly artifactPath: string;
    readonly artifactDigest: string;
    readonly descriptorDigest: string;
    readonly descriptor: unknown;
}
export interface ApplicationDeliveryPort {
    registerRelease(accountId: string, input: RegisterReleaseInput, idempotencyKey: string): Promise<unknown>;
    requestBuild(accountId: string, releaseId: string, input: Omit<BuildRequest, 'releaseId' | 'requestedBy'>, idempotencyKey: string): Promise<BuildReceipt>;
    getBuildReceipt(accountId: string, releaseId: string, attemptId: string): Promise<BuildReceipt>;
    publishRelease(accountId: string, releaseId: string, expectedStateVersion: number, idempotencyKey: string): Promise<unknown>;
    revokeRelease(accountId: string, releaseId: string, expectedStateVersion: number, reason: string, idempotencyKey: string): Promise<unknown>;
}
export interface BuildReceipt {
    readonly protocolVersion: typeof APP_DELIVERY_PROTOCOL_VERSION;
    readonly attemptId: string;
    readonly releaseId: string;
    readonly appId: string;
    readonly sourceCommit: string;
    readonly state: BuildAttemptState;
    readonly artifactDigest: string;
    readonly descriptorDigest: string;
    readonly uiDigest?: string;
    readonly runtimeDigest?: string;
    readonly compositionDigest?: string;
    readonly startedAt: string;
    readonly finishedAt?: string;
    readonly uiBundlePath?: string;
    readonly runtimeBundlePath?: string;
    readonly failureCode?: BuildFailureCode;
    /** A short, scrubbed message. Raw command output is never part of the receipt. */
    readonly message?: string;
}
export interface LaunchBundle {
    readonly protocolVersion: typeof APP_DELIVERY_PROTOCOL_VERSION;
    readonly tenantId: string;
    readonly actorId: string;
    readonly workspaceId: string;
    readonly installationId: string;
    readonly appId: string;
    readonly releaseId: string;
    readonly version: string;
    readonly artifactDigest: string;
    readonly descriptorDigest: string;
    readonly ui: PlatformUiExtensionDescriptor & {
        readonly artifactDigest: string;
        readonly bundlePath: string;
        readonly pages: readonly {
            readonly id: string;
            readonly title: string;
            readonly kind: PlatformPageKind;
            readonly requiredHostComponents: readonly string[];
        }[];
    };
    readonly runtime: readonly {
        readonly kind: string;
        readonly entry: string;
        readonly digest: string;
        readonly bundlePath: string;
    }[];
    readonly permissions: readonly {
        readonly actionId: string;
        readonly purposes: readonly DataPurpose[];
    }[];
    readonly dataDependencies: readonly DataDependencyContract[];
    readonly bridge: {
        readonly actions: readonly string[];
        readonly data: readonly string[];
        readonly conversation: boolean;
    };
}
/** Browser-visible projection. Runtime contributions stay in the server-side runtime manager. */
export type CustomerLaunchBundle = Omit<LaunchBundle, 'runtime'>;
/** Server-side qsBusiness ports supplied to a release-selected runtime contribution. */
export interface ApplicationRuntimeDataPort {
    list(logicalName: string, signal: AbortSignal): Promise<readonly Record<string, unknown>[]>;
    get(logicalName: string, recordId: string, signal: AbortSignal): Promise<Record<string, unknown> | null>;
    create(logicalName: string, input: Record<string, unknown>, operationId: string, signal: AbortSignal): Promise<Record<string, unknown>>;
    update(logicalName: string, recordId: string, input: Record<string, unknown>, operationId: string, signal: AbortSignal): Promise<Record<string, unknown>>;
}
export interface ApplicationRuntimeExecution {
    readonly actorId: string;
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly installationId: string;
    readonly operationId: string;
    readonly signal: AbortSignal;
    readonly data: ApplicationRuntimeDataPort;
    readonly actionIds: readonly string[];
    readonly dataDependencies: readonly DataDependencyContract[];
}
export interface ApplicationRuntimePort {
    executeAction(actionId: string, input: unknown, execution: ApplicationRuntimeExecution, runtimeDigest: string): Promise<unknown>;
}
export interface ActionGrant {
    readonly roleRef: string;
    readonly actionIds: readonly string[];
}
export interface ActionGrantRequest extends ActionGrant {
}
export type ApplicationActionResult = Readonly<Record<string, unknown>>;
export interface ApplicationDataPage {
    readonly items: readonly Record<string, unknown>[];
    readonly nextCursor?: string | null;
}
export type Conversation = ConversationRef;
export interface Accepted {
    readonly accepted: true;
}
export interface ConversationEventPage {
    readonly items: readonly ConversationEvent[];
    readonly nextCursor: string | null;
}
export declare function parseBuildRequest(value: unknown): BuildRequest;
export declare function parseActionGrant(value: unknown): ActionGrant;
export declare function assertBuildRequest(value: BuildRequest): void;
export declare function parseBuildReceipt(value: unknown): BuildReceipt;
export declare function parseLaunchBundle(value: unknown): LaunchBundle;
export declare function parseCustomerLaunchBundle(value: unknown): CustomerLaunchBundle;
export declare function parseApplicationActionResult(value: unknown): ApplicationActionResult;
export declare function parseApplicationDataPage(value: unknown): ApplicationDataPage;
export declare function parseConversation(value: unknown): Conversation;
export declare function parseAccepted(value: unknown): Accepted;
export declare function parseConversationEventPage(value: unknown): ConversationEventPage;
