import { type ActionGrant, type BuildReceipt, type BuildRequest, type RegisterReleaseInput } from './v3.ts';
export type BuildSubmission = Omit<BuildRequest, 'releaseId' | 'requestedBy' | 'idempotencyKey'>;
export interface ApplicationDeliveryApiClient {
    registerRelease(input: RegisterReleaseInput, idempotencyKey: string): Promise<Record<string, unknown>>;
    requestBuild(releaseId: string, input: BuildSubmission, idempotencyKey: string): Promise<BuildReceipt>;
    getBuildReceipt(releaseId: string, attemptId: string): Promise<BuildReceipt>;
    publishRelease(releaseId: string, expectedStateVersion: number, idempotencyKey: string): Promise<Record<string, unknown>>;
    revokeRelease(releaseId: string, expectedStateVersion: number, reason: string, idempotencyKey: string): Promise<Record<string, unknown>>;
    grantReleaseActions(releaseId: string, roleRef: string, actionIds: readonly string[], idempotencyKey: string): Promise<ActionGrant>;
}
/** Browser client for the operations-only V3 delivery routes. */
export declare function createApplicationDeliveryApiClient(fetchImpl?: typeof fetch): ApplicationDeliveryApiClient;
