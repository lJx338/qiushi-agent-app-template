import type { Installation } from './customer.ts';
import type { TenantSummary } from './operations.ts';
export type FixtureState = 'success' | 'empty' | 'forbidden' | 'disabled' | 'conflict';
export interface ErrorFixture {
    state: Exclude<FixtureState, 'success' | 'empty'>;
    status: 403 | 409;
    body: {
        code: 'ACTION_FORBIDDEN' | 'VERSION_CONFLICT' | 'IDEMPOTENCY_CONFLICT' | 'ENTITLEMENT_UNAVAILABLE';
        message: string;
        requestId: string;
    };
}
export declare const customerFixtures: {
    readonly success: {
        readonly me: {
            domain: "customer";
            actorId: string;
            displayName: string;
            tenants: {
                roles: readonly ["tenant.admin"];
                tenantId: string;
                businessCode: string;
                displayName: string;
                lifecycle: "active";
                version: number;
            }[];
            expiresAt: string;
        };
        readonly catalog: {
            appId: string;
            displayName: string;
            category: string;
            summary: string;
            visibility: "listed";
            availability: "available";
            unavailableReasons: never[];
            primaryAction: "launch";
            latestReleaseId: string;
            installationId: string;
        };
        readonly detail: {
            readonly appId: "qiushi.inventory";
            readonly displayName: "库存助手";
            readonly category: "supply-chain";
            readonly summary: "库存查询";
            readonly visibility: "listed";
            readonly availability: "available";
            readonly unavailableReasons: readonly [];
            readonly primaryAction: "launch";
            readonly latestReleaseId: "55555555-5555-4555-8555-555555555555";
            readonly installationId: string;
            readonly description: "库存查询与预警";
            readonly capabilities: readonly ["查询"];
            readonly inputs: readonly ["物料编码"];
            readonly outputs: readonly ["库存数量"];
            readonly dataUses: readonly ["库存数据"];
            readonly requiredActions: readonly ["qiushi.inventory.read"];
            readonly requiredData: readonly ["inventory"];
            readonly routeSegment: "inventory";
            readonly pages: readonly [{
                readonly id: "home";
                readonly title: "库存";
                readonly kind: "table";
            }];
        };
        readonly invitation: {
            readonly inviteId: "77777777-7777-4777-8777-777777777777";
            readonly claimUrl: "/claim";
            readonly expiresAt: "2030-01-01T00:00:00Z";
        };
        readonly installation: Installation;
    };
    readonly empty: {
        readonly catalog: {
            readonly items: readonly [];
            readonly nextCursor: null;
        };
        readonly members: {
            items: never[];
            nextCursor: null;
        };
    };
    readonly forbidden: {
        readonly error: {
            state: "forbidden";
            status: 403;
            body: {
                code: "ACTION_FORBIDDEN";
                message: string;
                requestId: string;
            };
        };
    };
    readonly disabled: {
        readonly catalog: {
            appId: string;
            displayName: string;
            category: string;
            summary: string;
            visibility: "listed";
            availability: "disabled";
            unavailableReasons: string[];
            primaryAction: "none";
        };
    };
    readonly conflict: {
        readonly error: {
            state: "conflict";
            status: 409;
            body: {
                code: "VERSION_CONFLICT";
                message: string;
                requestId: string;
            };
        };
    };
};
export declare const operationsFixtures: {
    readonly success: {
        readonly me: {
            domain: "operations";
            accountId: string;
            displayName: string;
            roles: "ops.operator"[];
            expiresAt: string;
        };
        readonly overview: {
            generatedAt: string;
            tenantCounts: {
                total: number;
                active: number;
                onboarding: number;
                paused: number;
                closed: number;
            };
            appCounts: {
                total: number;
                listed: number;
                hidden: number;
            };
            releaseCounts: {
                total: number;
                active: number;
                disabled: number;
            };
            attentionItems: never[];
        };
        readonly tenant: TenantSummary;
    };
    readonly empty: {
        readonly tenants: {
            readonly items: readonly [];
            readonly nextCursor: null;
        };
    };
    readonly forbidden: {
        readonly error: {
            state: "forbidden";
            status: 403;
            body: {
                code: "ACTION_FORBIDDEN";
                message: string;
                requestId: string;
            };
        };
    };
    readonly disabled: {
        readonly tenant: {
            readonly lifecycle: "paused";
            readonly tenantId: string;
            readonly businessCode: string;
            readonly displayName: string;
            readonly workspaceCount: number;
            readonly activeInstallationCount: number;
            readonly pendingInvitationCount: number;
            readonly version: number;
            readonly updatedAt: string;
        };
    };
    readonly conflict: {
        readonly error: {
            state: "conflict";
            status: 409;
            body: {
                code: "IDEMPOTENCY_CONFLICT";
                message: string;
                requestId: string;
            };
        };
    };
};
export declare const fixtureStates: readonly FixtureState[];
export interface ScenarioFixture {
    status: number;
    body?: unknown;
}
export interface OperationFixtureSet {
    success: ScenarioFixture;
    empty?: ScenarioFixture;
    forbidden: ScenarioFixture;
    disabled?: ScenarioFixture;
    failure: ScenarioFixture;
    conflict?: ScenarioFixture;
    replay?: ScenarioFixture;
    idempotencyConflict?: ScenarioFixture;
}
/** Every operation gets a schema-matched deterministic response; replay is the same response body/status. */
export declare const operationFixtures: Readonly<Record<string, OperationFixtureSet>>;
