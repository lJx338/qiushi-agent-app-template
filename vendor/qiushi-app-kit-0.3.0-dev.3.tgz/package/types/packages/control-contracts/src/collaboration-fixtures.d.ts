import type { FileDetail, Notification, RunDetail, TaskDetail, Workflow } from './collaboration.ts';
export interface CollaborationScenario {
    status: number;
    body?: unknown;
}
export interface CollaborationFixtureSet {
    success: CollaborationScenario;
    empty?: CollaborationScenario;
    forbidden: CollaborationScenario;
    disabled: CollaborationScenario;
    notFound: CollaborationScenario;
    failure: CollaborationScenario;
    conflict?: CollaborationScenario;
    replay?: CollaborationScenario;
    idempotencyConflict?: CollaborationScenario;
}
export declare const collaborationFixtures: {
    readonly success: {
        readonly task: TaskDetail;
        readonly workflow: Workflow;
        readonly notification: Notification;
        readonly run: RunDetail;
        readonly file: FileDetail;
    };
    readonly empty: {
        readonly taskPage: {
            readonly items: readonly [];
            readonly nextCursor: null;
        };
        readonly workflowPage: {
            readonly items: readonly [];
            readonly nextCursor: null;
        };
        readonly notificationPage: {
            readonly items: readonly [];
            readonly nextCursor: null;
        };
        readonly runPage: {
            readonly items: readonly [];
            readonly nextCursor: null;
        };
        readonly filePage: {
            readonly items: readonly [];
            readonly nextCursor: null;
        };
    };
    readonly uploadIntent: unknown;
    readonly downloadIntent: unknown;
};
export declare const collaborationOperationFixtures: Readonly<Record<string, CollaborationFixtureSet>>;
export declare const collaborationFixtureStates: readonly ["success", "empty", "forbidden", "disabled", "notFound", "failure", "conflict", "replay", "idempotencyConflict"];
