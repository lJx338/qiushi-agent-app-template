/** Public V1 control-plane DTOs.  They intentionally contain no database or browser-token types. */
export type Domain = 'customer' | 'operations';
export type TenantLifecycle = 'onboarding' | 'active' | 'paused' | 'closed';
export type InstallationStatus = 'configuring' | 'validating' | 'enabled' | 'disabled' | 'needs-attention' | 'upgrading' | 'upgrade-failed';
export type EntitlementStatus = 'granted' | 'suspended' | 'revoked';
export type OperationsRole = 'ops.access-admin' | 'ops.operator' | 'ops.publisher' | 'ops.support' | 'ops.auditor';
export type CustomerTenantRole = 'tenant.admin';
export interface Tenant {
    tenantId: string;
    businessCode: string;
    displayName: string;
    lifecycle: TenantLifecycle;
    version: number;
}
export interface CustomerTenant extends Tenant {
    roles: readonly CustomerTenantRole[];
}
export interface Workspace {
    workspaceId: string;
    displayName: string;
    state: 'enabled' | 'disabled';
}
export interface App {
    appId: string;
    displayName: string;
    category: string;
    summary: string;
    visibility: 'hidden' | 'listed';
    version: number;
}
export interface Entitlement {
    tenantId: string;
    appId: string;
    status: EntitlementStatus;
    startsAt: string;
    endsAt: string | null;
    allowedReleaseIds: readonly string[];
    version: number;
}
export interface Installation {
    installationId: string;
    tenantId: string;
    workspaceId: string;
    appId: string;
    releaseId: string;
    status: InstallationStatus;
    configVersion: number;
    authorizationVersion: number;
    canLaunch: boolean;
    unavailableReasons: readonly string[];
}
export interface CustomerMe {
    domain: 'customer';
    actorId: string;
    displayName: string;
    tenants: readonly CustomerTenant[];
    expiresAt: string;
}
export interface OperationsMe {
    domain: 'operations';
    accountId: string;
    displayName: string;
    roles: readonly OperationsRole[];
    expiresAt: string;
}
export interface CreateTenantInput {
    businessCode: string;
    displayName: string;
    workspaceName: string;
    reason: string;
}
export interface CreateAppInput {
    appId: string;
    displayName: string;
    category: string;
    summary: string;
    visibility: 'hidden' | 'listed';
}
export interface PutEntitlementInput {
    status: EntitlementStatus;
    startsAt: string;
    endsAt: string | null;
    allowedReleaseIds: readonly string[];
    expectedVersion: number;
    reason: string;
}
export interface ConfigureInstallationInput {
    expectedConfigVersion: number;
    config: Readonly<Record<string, unknown>>;
    permissionGrants: readonly string[];
    bindings: readonly {
        dependencyKey: string;
        bindingId: string;
        expectedMappingVersion: number;
    }[];
}
export interface UpgradeInstallationInput extends ConfigureInstallationInput {
    releaseId: string;
    confirmExpandedAccess?: boolean;
}
export interface V1Identity {
    id: string;
    issuer: string;
    subject: string;
    displayName: string;
    email?: string;
    roles: readonly OperationsRole[];
    expiresAt: Date;
}
export interface V1Session {
    token: string;
    identity: V1Identity;
    domain: Domain;
    expiresAt: Date;
    restrictedInvitationId?: string;
}
export type V1ErrorCode = 'SESSION_REQUIRED' | 'AUTH_DOMAIN_MISMATCH' | 'CSRF_REJECTED' | 'ACTION_FORBIDDEN' | 'RESOURCE_NOT_FOUND' | 'VERSION_CONFLICT' | 'VERSION_DIGEST_CONFLICT' | 'IDEMPOTENCY_CONFLICT' | 'ENTITLEMENT_UNAVAILABLE' | 'DATA_CONFIGURATION_REQUIRED' | 'RELEASE_UNAVAILABLE' | 'DEPENDENCY_UNAVAILABLE' | 'VALIDATION_FAILED';
export declare class V1Error extends Error {
    readonly code: V1ErrorCode;
    readonly status: number;
    constructor(code: V1ErrorCode, status: number, message?: V1ErrorCode);
}
export interface V1Store {
    createSession(domain: Domain, identity: V1Identity, restrictedInvitationId?: string): Promise<V1Session>;
    findSession(domain: Domain, token: string, now: Date): Promise<V1Session | null>;
    revokeSession(domain: Domain, token: string): Promise<void>;
    customerMe(actorId: string): Promise<CustomerMe>;
    listCustomerApps(actorId: string): Promise<readonly App[]>;
    resolveLaunch(actorId: string, tenantId: string, workspaceId: string, installationId: string): Promise<Installation>;
    operationsMe(accountId: string, expiresAt: Date): Promise<OperationsMe>;
    listTenants(accountId: string): Promise<readonly Tenant[]>;
    listApps(accountId: string): Promise<readonly App[]>;
    createTenant(accountId: string, input: CreateTenantInput, idempotencyKey: string): Promise<Tenant>;
    changeTenant(accountId: string, tenantId: string, input: {
        expectedVersion: number;
        lifecycle: 'active' | 'paused';
        reason: string;
    }, idempotencyKey: string): Promise<Tenant>;
    inviteFirstAdmin(accountId: string, tenantId: string, verifiedEmail: string, reason: string, claimBaseUrl: string, customerIssuer: string): Promise<{
        inviteId: string;
        claimUrl: string;
        expiresAt: string;
    }>;
    acceptInvitation(identity: V1Identity, inviteToken: string): Promise<CustomerMe>;
    createApp(accountId: string, input: CreateAppInput, idempotencyKey: string): Promise<App>;
    putEntitlement(accountId: string, tenantId: string, appId: string, input: PutEntitlementInput, idempotencyKey: string): Promise<Entitlement>;
    listWorkspaces(actorId: string, tenantId: string): Promise<readonly Workspace[]>;
    listInstallations(actorId: string, tenantId: string, workspaceId: string): Promise<readonly Installation[]>;
    prepareInstallation(actorId: string, tenantId: string, workspaceId: string, input: {
        appId: string;
        releaseId: string;
    }, idempotencyKey: string): Promise<Installation>;
    configureInstallation(actorId: string, tenantId: string, workspaceId: string, installationId: string, input: ConfigureInstallationInput): Promise<Installation>;
    transitionInstallation(actorId: string, tenantId: string, workspaceId: string, installationId: string, expectedConfigVersion: number, target: 'enabled' | 'disabled'): Promise<Installation>;
    upgradeInstallation?(actorId: string, tenantId: string, workspaceId: string, installationId: string, input: UpgradeInstallationInput): Promise<Installation>;
}
