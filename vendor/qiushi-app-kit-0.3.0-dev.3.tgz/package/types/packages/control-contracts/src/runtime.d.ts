/** Small dependency-free runtime helpers shared by the two public contract bundles. */
export declare class ContractValidationError extends Error {
    readonly path: string;
    constructor(message: string, path?: string);
}
export declare class ControlContractError extends Error {
    readonly code: string;
    readonly requestId: string;
    readonly status: number;
    readonly fieldErrors?: Readonly<Record<string, string[]>> | undefined;
    constructor(code: string, message: string, requestId: string, status: number, fieldErrors?: Readonly<Record<string, string[]>> | undefined);
}
export interface StandardError {
    code: string;
    message: string;
    requestId: string;
    fieldErrors?: Readonly<Record<string, readonly string[]>>;
}
export declare function parseStandardError(value: unknown): StandardError;
export declare function object(value: unknown, path?: string): Record<string, unknown>;
export declare function required<T = unknown>(value: Record<string, unknown>, key: string, path?: string): T;
export declare function string(value: unknown, path: string): string;
export declare function optionalString(value: unknown, path: string): string | undefined;
export declare function integer(value: unknown, path: string): number;
export declare function boolean(value: unknown, path: string): boolean;
export declare function array<T>(value: unknown, path: string, parse: (item: unknown, path: string) => T): T[];
export declare function isoDate(value: unknown, path: string): string;
export declare function expectEnum<T extends string>(value: unknown, values: readonly T[], path: string): T;
export declare function assertIdempotencyKey(key: string): void;
export declare function assertCas(value: number, header: 'expectedVersion' | 'expectedConfigVersion' | 'expectedStateVersion'): void;
export declare function decodeResponse(response: Response): Promise<unknown>;
export declare function requestJson<T>(fetchImpl: typeof fetch, path: string, init: RequestInit, parse: (value: unknown) => T): Promise<T>;
export declare const identity: <T>(value: T) => T;
