# Qiushi 独立应用开发包

平台维护的 SDK、DSH bridge、合成数据及 CLI。导出主契约、platform UI、tokens、development 测试入口和 dsh 桥接入口，业务源码不得引入 development。

源码与 monorepo 工具共用，发布构建时生成 JS、类型声明与开发资源，不包含平台业务页面、生产服务或凭证。当前开发版本 0.3.0-dev.3 通过 npm tgz 随公开模板分发，未发布公共 npm registry；0.3.0-dev.1 和 0.3.0-dev.2 归档保持不可变。版本与 package-lock integrity 固定，升级由平台重新发布；不编辑 node_modules。

`.2` 的 `BusinessData` 是发行驱动的通用端口：应用以有类型的 `data.get`、`data.list`、`data.create` 访问 manifest 声明的 logicalName；平台 runtime provider 负责作用域、字段投影和副作用，SDK 不携带客户或报价业务实现。

CLI：check、test、run、dev、build、pack、typecheck、verify；create 创建新的独立应用目录。全部为 development，不能提供真实 DSH Client、认证、持久业务或后台安装。

应用面向客户前台，沿用客户宿主身份；公司内部后台独立登录。数据库/文件/任务等能力只以实际导出契约为准，缺失能力由平台先设计后交付。模板源规范的修改需新 kit 版本才能进入其内置生成器，不覆盖已公开归档。
