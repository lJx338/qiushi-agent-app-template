import { type AnySchema } from 'ajv';
export type Json = null | boolean | number | string | Json[] | {
    [key: string]: Json;
};
export type ErrorCode = 'APP_NOT_ENABLED' | 'FORBIDDEN' | 'NOT_FOUND' | 'VALIDATION_FAILED' | 'OUTPUT_INVALID' | 'IDEMPOTENCY_REQUIRED' | 'IDEMPOTENCY_CONFLICT' | 'EXTERNAL_RESULT_UNKNOWN' | 'CANCELLED' | 'INTERNAL_ERROR';
export declare class AppError extends Error {
    readonly code: ErrorCode;
    constructor(code: ErrorCode, message: string);
}
/** Supplied by a trusted provider. This TS interface is NOT an authentication mechanism. */
export interface ExecutionContext {
    readonly tenantId: string;
    readonly actorId: string;
    readonly installationId: string;
    readonly appId: string;
    readonly appVersion: string;
    readonly enabled: boolean;
    readonly permissions: readonly string[];
}
export interface Customer {
    customerId: string;
    displayName: string;
}
export interface Draft {
    id: string;
    customerId: string;
    title: string;
    details: Json;
}
export type DataSourceAccessMode = 'tenant-shared' | 'user-delegated';
export type DataSourceLogicalResource = 'inquiry' | 'customer' | 'material' | 'attachment-metadata' | 'historical-quote';
export type DataSourcePurpose = 'ui' | 'model' | 'export';
export type DataSourceOperation = 'list' | 'get';
export type DataSourceBindingState = 'configuring' | 'validating' | 'enabled' | 'needs-attention' | 'disabled';
export type DataSourceFieldType = 'string' | 'integer' | 'decimal-string' | 'boolean' | 'date-time';
export interface DataSourceFieldMapping {
    readonly logicalField: string;
    readonly sourceField: string;
    readonly type: DataSourceFieldType;
    readonly required: boolean;
    readonly purposes: readonly DataSourcePurpose[];
}
export interface DataSourceResourceCapability {
    readonly logicalResource: DataSourceLogicalResource;
    readonly operations: readonly DataSourceOperation[];
    readonly accessModes: readonly DataSourceAccessMode[];
    readonly fields: readonly DataSourceFieldMapping[];
    readonly readOnly: true;
    readonly pagination: {
        readonly style: 'cursor';
        readonly maxPageSize: number;
    };
    readonly maxStaleSeconds: number;
}
export interface DataSourceDescriptor {
    readonly descriptorVersion: 'qiushi.data-source.v1';
    readonly providerId: string;
    readonly displayName: string;
    readonly readOnly: true;
    readonly tokenHandling: 'platform-managed';
    readonly capabilities: readonly DataSourceResourceCapability[];
    readonly rejectionPolicy: {
        readonly writes: 'reject';
        readonly arbitrarySourceReads: 'reject';
        readonly crossTenant: 'reject';
    };
}
export interface DataSourceBinding {
    readonly bindingId: string;
    readonly tenantId: string;
    readonly workspaceId?: string;
    readonly providerId: string;
    readonly logicalResource: DataSourceLogicalResource;
    readonly accessMode: DataSourceAccessMode;
    readonly sourceIdentity: DataSourceSourceIdentity;
    readonly purposes: readonly DataSourcePurpose[];
    readonly mappings: readonly DataSourceFieldMapping[];
    readonly state: DataSourceBindingState;
    readonly mappingVersion: number;
    readonly authorizationVersion: string;
    readonly maxStaleSeconds: number;
}
export interface DataSourceQueryRequest {
    readonly bindingId: string;
    readonly logicalResource: DataSourceLogicalResource;
    readonly operation: DataSourceOperation;
    readonly purpose: DataSourcePurpose;
    readonly fields: readonly string[];
    readonly sourceRecordId?: string;
    readonly cursor?: string | null;
    readonly limit?: number;
}
export interface DataSourceSourceIdentity {
    readonly mode: DataSourceAccessMode;
    readonly subjectRef?: string;
    readonly label?: string;
}
export interface DataSourceRecord {
    readonly recordId: string;
    readonly sourceRecordId: string;
    readonly sourceRowVersion: string;
    readonly fields: Readonly<Record<string, string | number | boolean>>;
    readonly sourceIdentity: DataSourceSourceIdentity;
    readonly sourceDigest: string;
    readonly observedAt: string;
}
export interface DataSourcePage {
    readonly logicalResource: DataSourceLogicalResource;
    readonly records: readonly DataSourceRecord[];
    readonly nextCursor: string | null;
    readonly sourceDigest: string;
    readonly fetchedAt: string;
    readonly staleAt: string;
    readonly fromCache: boolean;
}
/** Platform-provided logical data port. Apps never receive credentials or tenant selectors. */
export interface ReadOnlyDataSourcePort {
    query(request: DataSourceQueryRequest): Promise<DataSourcePage>;
}
export type DataSourceQueryPort = ReadOnlyDataSourcePort;
export type ReadOnlyQueryRequest = DataSourceQueryRequest;
export type ReadOnlyQueryPage = DataSourcePage;
/** Already scoped and authorized by the provider; application code cannot select a tenant. */
export interface BusinessData {
    get<T = BusinessRecord>(logicalName: string, id: string, signal: AbortSignal): Promise<T | undefined>;
    list<T = BusinessRecord>(logicalName: string, signal: AbortSignal): Promise<readonly T[]>;
    create<T = BusinessRecord>(logicalName: string, input: BusinessRecord, operationId: string, signal: AbortSignal): Promise<T>;
}
export type BusinessRecord = {
    [key: string]: Json;
};
export interface ActionExecution {
    readonly operationId: string;
    /** Trusted actor identity supplied by the platform; never derive this from action input. */
    readonly actorId: string;
    /** Trusted platform scope for development adapters and audit correlation. */
    readonly tenantId: string;
    readonly installationId: string;
    readonly signal: AbortSignal;
    readonly data: BusinessData;
    readonly dataSources?: ReadOnlyDataSourcePort;
}
export interface ActionDefinition {
    id: string;
    toolName: string;
    description: string;
    permissions: readonly string[];
    effects: 'none' | 'business-write';
    inputSchema: AnySchema;
    outputSchema: AnySchema;
    execute(input: Json, execution: ActionExecution): Promise<Json>;
}
export interface AppDefinition {
    id: string;
    version: string;
    actions: readonly ActionDefinition[];
}
export type UiPageKind = 'form' | 'table' | 'conversation' | 'mixed';
export type ScenarioKind = 'page' | 'conversation' | 'workflow';
export type ScenarioNavigation = 'customer' | 'internal' | 'operations';
export type ScenarioCapabilityVisibility = 'visible' | 'internal' | 'admin';
export interface ScenarioCapabilityRef {
    readonly id: string;
    readonly visibility: ScenarioCapabilityVisibility;
}
export interface AppScenario {
    readonly id: string;
    readonly kind: ScenarioKind;
    readonly entry: string;
    readonly route: string;
    readonly title: string;
    readonly navigation: ScenarioNavigation;
    readonly capabilities: readonly ScenarioCapabilityRef[];
    readonly purposes: readonly ('ui' | 'model' | 'export' | 'external-action')[];
    readonly businessDomains: readonly string[];
    readonly permissions: readonly string[];
}
/** Customer-readable product information. Technical declarations must never be projected into it. */
export interface AppDisplay {
    readonly overview: string;
    readonly capabilities: readonly string[];
    readonly inputs: readonly string[];
    readonly outputs: readonly string[];
    readonly dataUses: readonly string[];
}
export interface UiPageDeclaration {
    readonly id: string;
    readonly title: string;
    readonly kind: UiPageKind;
    readonly requiredHostComponents: readonly ('PageHeader' | 'Field' | 'DataTable' | 'ResultPanel' | 'ConversationPanel' | 'PermissionState' | 'ErrorState' | 'LoadingState')[];
}
export interface UiExtensionManifest {
    readonly apiVersion: 'qiushi.ui.v1';
    readonly entry: 'src/client/index.tsx';
    readonly routeSegment: string;
    readonly pages: readonly UiPageDeclaration[];
}
export interface DataDependencyDeclaration {
    readonly logicalName: string;
    readonly contractVersion: string;
    readonly required: boolean;
    readonly operations: readonly ('list' | 'get' | 'create' | 'update')[];
    readonly fields: readonly {
        readonly name: string;
        readonly type: 'string' | 'integer' | 'decimal-string' | 'boolean' | 'date-time' | 'json';
        readonly required: boolean;
        readonly purposes: readonly ('ui' | 'model' | 'export' | 'external-action')[];
    }[];
    readonly accessMode: 'tenant-shared' | 'delegated-user';
    readonly purposes: readonly ('ui' | 'model' | 'export' | 'external-action')[];
}
/** Public, development-only v2 release descriptor. The platform must revalidate its digest and authorization. */
export interface AppReleaseDescriptorV2 {
    readonly formatVersion: 'qiushi.app-release.v2';
    readonly appId: string;
    readonly version: string;
    readonly stage: 'development';
    readonly archive: string;
    readonly sha256: string;
    readonly runtimeBaseline: string;
    readonly display: AppDisplay;
    readonly ui: UiExtensionManifest & {
        readonly pageKind: UiPageKind;
        readonly requiredHostComponents: readonly UiPageDeclaration['requiredHostComponents'][number][];
        readonly sha256: string;
    };
    readonly runtime: readonly {
        readonly kind: 'dsh-tool';
        readonly entry: 'src/host.ts';
        readonly sha256: string;
    }[];
    readonly dataDependencies: readonly DataDependencyDeclaration[];
    readonly scenarios: readonly AppScenario[];
    readonly permissions: readonly {
        readonly actionId: string;
        readonly purposes: readonly ('ui' | 'model' | 'export' | 'external-action')[];
        readonly declaredPermissions?: readonly string[];
    }[];
    readonly capabilities?: {
        readonly registryVersion: 1;
        readonly entries: readonly {
            readonly id: string;
            readonly version: string;
            readonly digest: string;
            readonly permissions: readonly string[];
            readonly dataPurposes: readonly string[];
            readonly required: boolean;
            readonly requestedPurposes: readonly string[];
        }[];
    };
    readonly productionReady: false;
}
/** Runtime shape check mirroring the frozen control-plane v2 core before a development artifact is emitted. */
export declare function assertAppReleaseDescriptorV2(value: unknown): asserts value is AppReleaseDescriptorV2;
export declare function validateValue(schema: AnySchema, value: unknown, code?: ErrorCode): asserts value is Json;
export declare function defineApp(app: AppDefinition): AppDefinition;
/**
 * In-process contract-test executor only. No durable storage, process isolation,
 * authentication, distributed lock, or exactly-once guarantee is provided here.
 * Production qsBusiness must supply those facilities; never import this from host.ts.
 */
export declare class DevelopmentExecutor {
    private readonly dataFor;
    private readonly operations;
    readonly audit: {
        actionId: string;
        tenantId: string;
        actorId: string;
        status: string;
    }[];
    constructor(dataFor: (context: ExecutionContext, action: ActionDefinition) => BusinessData);
    execute(app: AppDefinition, actionId: string, rawInput: unknown, context: ExecutionContext, options?: {
        idempotencyKey?: string;
        signal?: AbortSignal;
    }): Promise<Json>;
}
