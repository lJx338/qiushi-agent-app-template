import React, { type ReactNode } from 'react';
export { PlatformUiRegistry, type VerifiedUiRegistration } from './registry.ts';
export declare const PLATFORM_UI_API_VERSION: "qiushi.ui.v1";
export declare const hostComponentNames: readonly ["PageHeader", "Field", "DataTable", "ResultPanel", "ConversationPanel", "PermissionState", "ErrorState", "LoadingState"];
export type HostComponentName = typeof hostComponentNames[number];
export type PlatformPageKind = 'form' | 'table' | 'conversation' | 'mixed';
export interface PlatformPageDeclaration {
    readonly id: string;
    readonly title: string;
    readonly kind: PlatformPageKind;
    readonly requiredHostComponents: readonly HostComponentName[];
}
/** A reviewed extension module. It receives only this narrow bridge from the platform host. */
export interface PlatformUiExtension {
    readonly apiVersion: typeof PLATFORM_UI_API_VERSION;
    readonly appId: string;
    readonly pages: readonly PlatformPageDeclaration[];
    readonly render: (bridge: PlatformUiBridge) => ReactNode;
}
export interface ConversationEvent {
    readonly eventId: string;
    readonly cursor: number;
    readonly type: 'assistant.delta' | 'tool.started' | 'tool.completed' | 'turn.completed' | 'turn.failed' | 'turn.cancelled';
    readonly data: Readonly<Record<string, unknown>>;
}
export interface PlatformUiBridge {
    readonly loginState: 'authenticated' | 'required';
    readonly scenario: {
        readonly id: string;
        readonly route: string;
        readonly title: string;
    };
    /** Host validates the route against this installation's launch bundle before navigation. */
    readonly navigate: (route: string) => void;
    readonly actions: {
        /** Action IDs are declared in the manifest and re-authorized by the platform. */
        execute<T>(actionId: string, input: unknown): Promise<T>;
    };
    readonly data: {
        list(logicalName: string): Promise<readonly Record<string, unknown>[]>;
        get(logicalName: string, recordId: string): Promise<Record<string, unknown> | null>;
    };
    readonly conversation: {
        create(): Promise<{
            conversationId: string;
        }>;
        send(conversationId: string, message: string): Promise<void>;
        cancel(conversationId: string): Promise<void>;
        subscribe(conversationId: string, cursor: number, receive: (event: ConversationEvent) => void, disconnected: () => void): () => void;
    };
}
/** Single platform-owned registration point: extensions never mount themselves or choose a route. */
export declare function PlatformUiHost({ extension, sourceUrl, expectedDigest, moduleResolver: _moduleResolver, bridge, appId, routeSegment, pages, allowedActions, allowedData, conversationEnabled, allowedScenarioRoutes }: {
    extension?: PlatformUiExtension;
    sourceUrl?: string;
    expectedDigest?: string;
    moduleResolver?: (specifier: string) => string | undefined;
    bridge: PlatformUiBridge;
    appId: string;
    routeSegment: string;
    pages: readonly PlatformPageDeclaration[];
    allowedActions?: readonly string[];
    allowedData?: readonly string[];
    conversationEnabled?: boolean;
    allowedScenarioRoutes?: readonly string[];
}): import("react/jsx-runtime").JSX.Element;
export declare function defineUiExtension(extension: PlatformUiExtension): PlatformUiExtension;
export declare function PageHeader({ title, description, status, actions }: {
    title: string;
    description: string;
    status?: string;
    actions?: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function Field({ label, error, children }: {
    label: string;
    error?: string;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function ActionButton({ children, loading, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & {
    loading?: boolean;
}): import("react/jsx-runtime").JSX.Element;
export declare function DataTable({ columns, rows, loading, empty }: {
    columns: readonly string[];
    rows: readonly (readonly ReactNode[])[];
    loading?: boolean;
    empty?: string;
}): import("react/jsx-runtime").JSX.Element;
export declare function ResultPanel({ title, children }: {
    title: string;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function LoadingState({ label }: {
    label?: string;
}): import("react/jsx-runtime").JSX.Element;
export declare function PermissionState({ message }: {
    message?: string;
}): import("react/jsx-runtime").JSX.Element;
export declare function ErrorState({ message }: {
    message: string;
}): import("react/jsx-runtime").JSX.Element;
export declare function ConversationPanel({ bridge, title }: {
    bridge: PlatformUiBridge;
    title?: string;
}): import("react/jsx-runtime").JSX.Element;
