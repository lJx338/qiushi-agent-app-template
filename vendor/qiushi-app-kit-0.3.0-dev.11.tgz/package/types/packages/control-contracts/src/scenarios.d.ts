import type { CapabilityLock, CapabilityRecord } from './capabilities.ts';
export declare const SCENARIO_KINDS: readonly ["page", "conversation", "workflow"];
export type ScenarioKind = typeof SCENARIO_KINDS[number];
export declare const SCENARIO_NAVIGATIONS: readonly ["customer", "internal", "operations"];
export type ScenarioNavigation = typeof SCENARIO_NAVIGATIONS[number];
export declare const CUSTOMER_HOST_RESERVED_SCENARIO_ROUTES: readonly ["about"];
export declare const SCENARIO_PURPOSES: readonly ["ui", "model", "export", "external-action"];
export type ScenarioPurpose = typeof SCENARIO_PURPOSES[number];
export type ScenarioCapabilityVisibility = 'visible' | 'internal' | 'admin';
export interface ScenarioCapabilityRef {
    readonly id: string;
    readonly visibility: ScenarioCapabilityVisibility;
}
/** A product entry point. Capabilities are optional and never become navigation by implication. */
export interface ApplicationScenario {
    readonly id: string;
    readonly kind: ScenarioKind;
    readonly entry: string;
    readonly route: string;
    readonly title: string;
    readonly navigation: ScenarioNavigation;
    readonly capabilities: readonly ScenarioCapabilityRef[];
    readonly purposes: readonly ScenarioPurpose[];
    readonly businessDomains: readonly string[];
    readonly permissions: readonly string[];
}
export interface ApplicationScenarioManifest {
    readonly manifestVersion: '2';
    readonly appId: string;
    readonly version: string;
    readonly scenarios: readonly ApplicationScenario[];
    readonly capabilityLock?: CapabilityLock;
}
export declare function parseApplicationScenario(value: unknown, path?: string): ApplicationScenario;
export declare function parseApplicationScenarios(value: unknown, path?: string): readonly ApplicationScenario[];
/** Keeps manifest, release packaging, and catalog registration aligned with customer-host routing. */
export declare function validateScenarioPageClosure(scenarios: readonly ApplicationScenario[], ui: {
    readonly entry: string;
    readonly pages: readonly {
        readonly id: string;
        readonly title: string;
    }[];
}): void;
export declare function parseApplicationScenarioManifest(value: unknown): ApplicationScenarioManifest;
/** Checks scenario references without creating another dependency or permission format. */
export declare function validateScenarioCapabilities(scenarios: readonly ApplicationScenario[], lock: CapabilityLock, registry: readonly CapabilityRecord[]): void;
