import type { DataDependencyContract, DataPurpose } from './data-foundation.ts';
import type { PlatformUiExtensionDescriptor } from './ui-extension.ts';
import type { ApplicationScenario } from './scenarios.ts';
import type { CapabilityLock } from './capabilities.ts';
export declare const APP_RELEASE_FORMAT_VERSION: "qiushi.app-release.v2";
export interface RuntimeContributionDescriptor {
    readonly kind: 'dsh-patch' | 'dsh-tool' | 'dsh-preset' | 'dsh-workflow';
    readonly entry: string;
    readonly sha256: string;
}
export interface PermissionDeclaration {
    readonly actionId: string;
    readonly purposes: readonly DataPurpose[];
}
export interface ProductDisplay {
    readonly overview: string;
    readonly capabilities: readonly string[];
    readonly inputs: readonly string[];
    readonly outputs: readonly string[];
    readonly dataUses: readonly string[];
}
/** Immutable release input consumed by validation and installation control planes. */
export interface AppReleaseDescriptorV2 {
    readonly formatVersion: typeof APP_RELEASE_FORMAT_VERSION;
    readonly appId: string;
    readonly version: string;
    readonly runtimeBaseline: string;
    readonly display: ProductDisplay;
    readonly ui: PlatformUiExtensionDescriptor;
    readonly runtime: readonly RuntimeContributionDescriptor[];
    readonly dataDependencies: readonly DataDependencyContract[];
    readonly capabilities?: CapabilityLock;
    readonly scenarios: readonly ApplicationScenario[];
    readonly permissions: readonly PermissionDeclaration[];
}
export type AppReleaseState = 'draft' | 'quarantined' | 'validating' | 'ready-for-review' | 'published' | 'deprecated' | 'revoked' | 'rejected';
export type AppInstallationState = 'configuring' | 'validating' | 'enabled' | 'disabled' | 'needs-attention' | 'upgrading' | 'upgrade-failed';
