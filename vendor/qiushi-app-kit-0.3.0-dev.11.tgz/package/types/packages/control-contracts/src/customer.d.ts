import type { ControlContractError } from './runtime.ts';
import { type Accepted, type ApplicationActionResult, type ApplicationDataPage, type Conversation, type ConversationEventPage, type CustomerLaunchBundle as LaunchBundle } from './v3.ts';
import type { UpgradeInstallationInput } from './v1.ts';
import { type CustomerCollaborationApiClient } from './collaboration.ts';
export type CustomerTenantLifecycle = 'onboarding' | 'active' | 'paused' | 'closed';
export type CustomerTenantRole = 'tenant.admin';
export type CustomerInstallationStatus = 'configuring' | 'validating' | 'enabled' | 'disabled' | 'needs-attention' | 'upgrading' | 'upgrade-failed';
export type Availability = 'available' | 'configuration-required' | 'disabled' | 'unavailable';
export type PrimaryAction = 'launch' | 'configure' | 'request-access' | 'none';
export interface CustomerTenant {
    tenantId: string;
    businessCode: string;
    displayName: string;
    lifecycle: CustomerTenantLifecycle;
    version: number;
    roles: readonly CustomerTenantRole[];
}
export interface CustomerMe {
    domain: 'customer';
    actorId: string;
    displayName: string;
    tenants: readonly CustomerTenant[];
    expiresAt: string;
}
export interface Workspace {
    workspaceId: string;
    displayName: string;
    state: 'enabled' | 'disabled';
}
export interface CatalogCard {
    appId: string;
    displayName: string;
    category: string;
    summary: string;
    visibility: 'hidden' | 'listed';
    latestReleaseId?: string;
    installationId?: string;
    availability: Availability;
    unavailableReasons: readonly string[];
    primaryAction: PrimaryAction;
}
export interface CatalogPage {
    items: readonly CatalogCard[];
    nextCursor: string | null;
}
export interface CustomerApp {
    appId: string;
    displayName: string;
    category: string;
    summary: string;
    visibility: 'hidden' | 'listed';
    version: number;
}
export interface AppPage {
    items: readonly CustomerApp[];
    nextCursor: string | null;
}
export interface CatalogDetail extends CatalogCard {
    description: string;
    capabilities: readonly string[];
    inputs: readonly string[];
    outputs: readonly string[];
    dataUses: readonly string[];
    requiredActions: readonly string[];
    requiredData: readonly string[];
    routeSegment?: string;
    pages: readonly {
        id: string;
        title: string;
        kind: 'form' | 'table' | 'conversation' | 'mixed';
    }[];
    releaseVersion?: number;
}
export interface WorkspaceHome {
    tenantId: string;
    tenantDisplayName: string;
    workspaceId: string;
    workspaceDisplayName: string;
    recommended: readonly CatalogCard[];
    recentInstallations: readonly Installation[];
    attentionItems: readonly string[];
}
export interface LaunchDescriptor {
    installation: Installation;
    ui: {
        apiVersion: 'qiushi.ui.v1';
        registryKey: string;
        artifactDigest: string;
        routeSegment: string;
        pages: readonly {
            id: string;
            title: string;
            kind: 'form' | 'table' | 'conversation' | 'mixed';
        }[];
    };
}
export interface Installation {
    installationId: string;
    tenantId: string;
    workspaceId: string;
    appId: string;
    releaseId: string;
    status: CustomerInstallationStatus;
    configVersion: number;
    authorizationVersion: number;
    canLaunch: boolean;
    unavailableReasons: readonly string[];
}
export interface InstallationPage {
    items: readonly Installation[];
    nextCursor: string | null;
}
export interface Member {
    memberId: string;
    actorId: string;
    displayName: string;
    email?: string;
    status: 'active' | 'pending' | 'suspended' | 'revoked';
    roles: readonly string[];
    workspaceIds: readonly string[];
    version: number;
}
export interface MemberPage {
    items: readonly Member[];
    nextCursor: string | null;
}
export interface MemberInvitationInput {
    verifiedEmail: string;
    roles: readonly string[];
    workspaceIds: readonly string[];
    reason: string;
}
export interface MemberPatchInput {
    expectedVersion: number;
    status: Member['status'];
    roles: readonly string[];
    workspaceIds: readonly string[];
    reason: string;
}
export interface InvitationCreated {
    inviteId: string;
    claimUrl: string;
    expiresAt: string;
}
export interface DataBindingSummary {
    bindingId: string;
    logicalName: string;
    contractVersion?: string;
    provider: string;
    capabilities: readonly string[];
    state: 'configuring' | 'validating' | 'enabled' | 'needs-attention' | 'disabled';
    mappingVersion: number;
    authorizationVersion: string;
    affectedInstallationIds: readonly string[];
}
export interface DataBindingLifecycleInput {
    expectedAuthorizationVersion: string;
    reason: string;
}
export interface DataBindingPage {
    items: readonly DataBindingSummary[];
    nextCursor: string | null;
}
export interface ConfigureInstallationInput {
    expectedConfigVersion: number;
    config: Readonly<Record<string, unknown>>;
    permissionGrants: readonly string[];
    bindings: readonly {
        dependencyKey: string;
        bindingId: string;
        expectedMappingVersion: number;
    }[];
}
export declare function parseCustomerTenant(value: unknown, path?: string): CustomerTenant;
export declare function parseCustomerMe(value: unknown): CustomerMe;
export declare function parseWorkspace(value: unknown, path?: string): Workspace;
export declare function parseWorkspaceHome(value: unknown): WorkspaceHome;
export declare function parseInstallation(value: unknown, path?: string): Installation;
export declare function parseCatalogCard(value: unknown, path?: string): CatalogCard;
export declare function parseCustomerApp(value: unknown, path?: string): CustomerApp;
export declare function parseCatalogDetail(value: unknown): CatalogDetail;
export declare function parseMember(value: unknown, path?: string): Member;
export declare function parseDataBinding(value: unknown, path?: string): DataBindingSummary;
export declare function parseInvitationCreated(value: unknown): InvitationCreated;
export declare function parseLaunchDescriptor(value: unknown): LaunchDescriptor;
export interface CustomerApiClient extends CustomerCollaborationApiClient {
    getMe(): Promise<CustomerMe>;
    logout(): Promise<void>;
    listApps(options?: ListOptions): Promise<AppPage>;
    acceptInvitation(inviteToken: string): Promise<CustomerTenant>;
    listWorkspaces(tenantId: string, options?: ListOptions): Promise<{
        items: readonly Workspace[];
        nextCursor: string | null;
    }>;
    getWorkspaceHome(tenantId: string, workspaceId: string): Promise<WorkspaceHome>;
    listCatalog(tenantId: string, workspaceId: string, options?: ListOptions): Promise<CatalogPage>;
    getCatalogDetail(tenantId: string, workspaceId: string, appId: string): Promise<CatalogDetail>;
    listInstallations(tenantId: string, workspaceId: string, options?: ListOptions): Promise<InstallationPage>;
    getInstallation(tenantId: string, workspaceId: string, installationId: string): Promise<Installation>;
    resolveLaunch(tenantId: string, workspaceId: string, installationId: string): Promise<LaunchDescriptor>;
    resolveLaunchBundle?(tenantId: string, workspaceId: string, installationId: string): Promise<LaunchBundle>;
    listMembers(tenantId: string, options?: ListOptions): Promise<MemberPage>;
    inviteMember(tenantId: string, input: MemberInvitationInput, idempotencyKey: string): Promise<InvitationCreated>;
    patchMember(tenantId: string, memberId: string, input: MemberPatchInput, idempotencyKey: string): Promise<Member>;
    listDataBindings(tenantId: string, options?: ListOptions): Promise<DataBindingPage>;
    createDataBinding(tenantId: string, input: {
        logicalName: 'customer' | 'quote-draft';
        contractVersion?: '1';
    }, idempotencyKey: string): Promise<DataBindingSummary>;
    disableDataBinding(tenantId: string, bindingId: string, input: DataBindingLifecycleInput, idempotencyKey: string): Promise<DataBindingSummary>;
    revokeDataBinding(tenantId: string, bindingId: string, input: DataBindingLifecycleInput, idempotencyKey: string): Promise<DataBindingSummary>;
    prepareInstallation(tenantId: string, workspaceId: string, input: {
        appId: string;
        releaseId: string;
    }, idempotencyKey: string): Promise<Installation>;
    configureInstallation(tenantId: string, workspaceId: string, installationId: string, input: ConfigureInstallationInput, idempotencyKey?: string): Promise<Installation>;
    transitionInstallation(tenantId: string, workspaceId: string, installationId: string, expectedConfigVersion: number, target: 'enabled' | 'disabled'): Promise<Installation>;
    upgradeInstallation(tenantId: string, workspaceId: string, installationId: string, input: UpgradeInstallationInput): Promise<Installation>;
    executeApplicationAction(input: {
        tenantId: string;
        workspaceId: string;
        installationId: string;
        actionId: string;
        input: Record<string, unknown>;
        idempotencyKey: string;
    }): Promise<ApplicationActionResult>;
    listApplicationData(tenantId: string, workspaceId: string, installationId: string, logicalName: string): Promise<ApplicationDataPage>;
    createConversation(scope: {
        tenantId: string;
        workspaceId: string;
        installationId: string;
    }): Promise<Conversation>;
    sendConversationMessage(conversationId: string, scope: {
        tenantId: string;
        workspaceId: string;
        installationId: string;
    }, message: string): Promise<Accepted>;
    listConversationEvents(conversationId: string, scope: {
        tenantId: string;
        workspaceId: string;
        installationId: string;
    }, cursor?: number): Promise<ConversationEventPage>;
    cancelConversation(conversationId: string, scope: {
        tenantId: string;
        workspaceId: string;
        installationId: string;
    }): Promise<Accepted>;
}
export interface ListOptions {
    limit?: number;
    cursor?: string;
}
export declare const parseCatalogPage: (x: unknown) => {
    items: CatalogCard[];
    nextCursor: string | null;
};
export declare const parseAppPage: (x: unknown) => {
    items: CustomerApp[];
    nextCursor: string | null;
};
export declare const parseWorkspacePage: (x: unknown) => {
    items: Workspace[];
    nextCursor: string | null;
};
export declare const parseInstallationPage: (x: unknown) => {
    items: Installation[];
    nextCursor: string | null;
};
export declare const parseMemberPage: (x: unknown) => {
    items: Member[];
    nextCursor: string | null;
};
export declare const parseDataBindingPage: (x: unknown) => {
    items: DataBindingSummary[];
    nextCursor: string | null;
};
export declare function parseDataBindingLifecycleInput(value: unknown, path?: string): DataBindingLifecycleInput;
export declare function createCustomerApiClient(fetchImpl?: typeof fetch): CustomerApiClient;
export type CustomerClientError = ControlContractError;
