export type CoordinationEndpoint = Readonly<{
    domain: 'customer' | 'operations';
    method: 'GET' | 'POST';
    path: string;
    operationId: string;
    successStatus: 200 | 201;
    successSchema: string;
    idempotency: boolean;
    cas: boolean;
}>;
export declare const coordinationEndpointMatrix: readonly CoordinationEndpoint[];
