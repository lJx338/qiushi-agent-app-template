import type { CapabilityLock, CapabilityRecord } from './capabilities.ts';
export type DeveloperRole = 'developer' | 'maintainer' | 'platform.publisher' | 'platform.admin';
export type DeveloperProjectStatus = 'active' | 'archived';
export type DeveloperValidationStatus = 'passed' | 'failed';
export type DeveloperSubmissionStatus = 'submitted' | 'accepted' | 'rejected' | 'revoked';
export type DeveloperBuildStatus = 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
export interface DeveloperSessionContext {
    readonly developerId: string;
    readonly workspaceId: string;
    readonly roles: readonly DeveloperRole[];
    readonly authEpoch: string;
    readonly expiresAt: string;
}
export interface DeveloperMe {
    readonly domain: 'developer';
    readonly developerId: string;
    readonly workspace: DeveloperWorkspace;
    readonly roles: readonly DeveloperRole[];
    readonly expiresAt: string;
}
export interface DeveloperWorkspace {
    readonly workspaceId: string;
    readonly displayName: string;
    readonly status: 'active' | 'suspended';
    readonly version: number;
    readonly updatedAt: string;
}
export interface DeveloperMember {
    readonly memberId: string;
    readonly workspaceId: string;
    readonly developerId: string;
    readonly displayName: string;
    readonly role: DeveloperRole;
    readonly status: 'active' | 'revoked';
    readonly version: number;
}
export interface DeveloperProject {
    readonly projectId: string;
    readonly workspaceId: string;
    readonly appId: string;
    readonly displayName: string;
    readonly template: string;
    readonly runtimeBaseline: string;
    readonly status: DeveloperProjectStatus;
    readonly manifestDigest: string | null;
    readonly capabilityLockDigest: string | null;
    readonly version: number;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface DeveloperValidation {
    readonly validationId: string;
    readonly projectId: string;
    readonly status: DeveloperValidationStatus;
    readonly inputDigest: string;
    readonly manifestDigest: string | null;
    readonly capabilityLockDigest: string | null;
    readonly errors: readonly DeveloperFieldError[];
    readonly runtimeBaseline: string;
    readonly createdAt: string;
}
export interface DeveloperFieldError {
    readonly code: string;
    readonly field: string;
    readonly message: string;
}
export interface DeveloperSubmission {
    readonly submissionId: string;
    readonly projectId: string;
    readonly sourceRepository: string;
    readonly sourceCommit: string;
    readonly artifactDigest: string;
    readonly descriptorDigest: string;
    readonly capabilityLock: CapabilityLock;
    readonly status: DeveloperSubmissionStatus;
    readonly version: number;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface DeveloperBuildAttempt {
    readonly attemptId: string;
    readonly submissionId: string;
    readonly attempt: number;
    readonly idempotencyKey: string;
    readonly status: DeveloperBuildStatus;
    readonly receipt: DeveloperBuildReceipt | null;
    readonly failureCode?: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface DeveloperBuildReceipt {
    readonly attemptId: string;
    readonly submissionId: string;
    readonly status: 'succeeded' | 'failed';
    readonly artifactDigest: string | null;
    readonly descriptorDigest: string | null;
    readonly capabilityLockDigest: string | null;
    readonly completedAt: string;
    readonly failureCode?: string;
}
/** The only payload allowed across the developer → operations boundary. */
export interface DeveloperOperationsHandoff {
    readonly submissionId: string;
    readonly artifactDigest: string;
    readonly descriptorDigest: string;
    readonly capabilityLock: CapabilityLock;
}
export interface CreateDeveloperProjectInput {
    readonly appId: string;
    readonly displayName: string;
    readonly template: string;
    readonly runtimeBaseline: string;
}
export interface SubmitDeveloperValidationInput {
    readonly inputDigest: string;
    readonly manifestDigest?: string;
    readonly capabilityLockDigest?: string;
    readonly status: DeveloperValidationStatus;
    readonly errors?: readonly DeveloperFieldError[];
    readonly runtimeBaseline: string;
}
export interface CreateDeveloperSubmissionInput {
    readonly sourceRepository: string;
    readonly sourceCommit: string;
    readonly artifactDigest: string;
    readonly descriptorDigest: string;
    readonly capabilityLock: CapabilityLock;
}
export interface DeveloperCapabilityQuery {
    readonly kind?: string;
    readonly version?: string;
    readonly visibility?: string;
    readonly status?: string;
}
export interface DeveloperApiClient {
    getMe(): Promise<DeveloperMe>;
    listProjects(): Promise<{
        items: readonly DeveloperProject[];
        nextCursor: string | null;
    }>;
    createProject(input: CreateDeveloperProjectInput, idempotencyKey: string): Promise<DeveloperProject>;
    listCapabilities(query?: DeveloperCapabilityQuery): Promise<{
        items: readonly CapabilityRecord[];
        nextCursor: string | null;
    }>;
    submitValidation(projectId: string, input: SubmitDeveloperValidationInput, idempotencyKey: string): Promise<DeveloperValidation>;
    createSubmission(projectId: string, input: CreateDeveloperSubmissionInput, idempotencyKey: string, expectedVersion: number): Promise<DeveloperSubmission>;
    requestBuild(submissionId: string, idempotencyKey: string, expectedVersion: number): Promise<DeveloperBuildAttempt>;
    getBuildReceipt(submissionId: string): Promise<DeveloperBuildAttempt>;
}
export declare const parseDeveloperMe: (x: unknown) => DeveloperMe;
export declare const parseDeveloperWorkspace: (x: unknown) => DeveloperWorkspace;
export declare const parseDeveloperProject: (x: unknown) => DeveloperProject;
export declare const parseDeveloperMember: (x: unknown) => DeveloperMember;
export declare const parseDeveloperValidation: (x: unknown) => DeveloperValidation;
export declare const parseDeveloperSubmission: (x: unknown) => DeveloperSubmission;
export declare const parseDeveloperBuildAttempt: (x: unknown) => DeveloperBuildAttempt;
export declare const parseDeveloperBuildReceipt: (x: unknown) => DeveloperBuildReceipt;
export declare const parseDeveloperCapabilityLock: (x: unknown) => CapabilityLock;
export declare const parseDeveloperCapability: (x: unknown) => CapabilityRecord;
export declare const toDeveloperOperationsHandoff: (submission: DeveloperSubmission) => DeveloperOperationsHandoff;
export declare function validateDeveloperCapabilityLock(lock: CapabilityLock, registry: readonly CapabilityRecord[]): void;
export declare function createDeveloperApiClient(fetchImpl?: typeof fetch): DeveloperApiClient;
