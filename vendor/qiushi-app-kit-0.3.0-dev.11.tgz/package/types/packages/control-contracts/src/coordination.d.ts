import type { BusinessReference } from './collaboration.ts';
import type { AuthEpoch } from './auth-epoch.ts';
export type CollaborationPurpose = 'ui' | 'model' | 'export' | 'external-action';
export type AuthorizationMode = 'delegated-user' | 'tenant-shared' | 'service';
export type RevocationCheck = 'before-dispatch-and-before-result' | 'before-dispatch' | 'none';
export type AuditRequirement = 'required' | 'optional';
/** Shared command policy; endpoints must not invent per-resource permission semantics. */
export interface CollaborationPolicy {
    readonly permission: string;
    readonly purposes: readonly CollaborationPurpose[];
    readonly authorizationMode: AuthorizationMode;
    readonly idempotency: 'required' | 'optional' | 'none';
    readonly cas: 'required' | 'optional' | 'none';
    readonly audit: AuditRequirement;
    readonly revocation: RevocationCheck;
}
export interface CollaborationCommand {
    readonly businessReference: BusinessReference;
    readonly policy: CollaborationPolicy;
    readonly idempotencyKey?: string;
    readonly expectedVersion?: number;
}
export type CoordinationDecision = 'allowed' | 'forbidden' | 'revoked' | 'cross-tenant' | 'cross-application' | 'conflict' | 'replayed' | 'unknown';
export interface CollaborationAuthorizationResult {
    readonly decision: CoordinationDecision;
    readonly operationId: string;
    readonly authorizationVersion: AuthEpoch;
    readonly auditId: string;
    readonly businessReference: BusinessReference;
    readonly reasonCode?: string;
}
export interface BusinessEventEnvelope {
    readonly eventId: string;
    readonly eventVersion: number;
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly type: string;
    readonly operationId: string;
    readonly businessReference: BusinessReference;
    readonly occurredAt: string;
    readonly traceId: string;
    readonly data: Readonly<Record<string, unknown>>;
}
export interface CoordinationTaskReference {
    readonly taskId: string;
    readonly businessReference: BusinessReference;
    readonly sourceAppId: string;
    readonly targetAppId?: string;
    readonly permission: string;
    readonly purposes: readonly CollaborationPurpose[];
    readonly status: 'pending' | 'in-progress' | 'completed' | 'cancelled' | 'failed' | 'revoked';
    readonly version: number;
    readonly authorizationVersion: AuthEpoch;
}
export interface ApprovalReference {
    readonly approvalId: string;
    readonly businessReference: BusinessReference;
    readonly actionHash: string;
    readonly requestedBy: string;
    readonly decidedBy?: string;
    readonly status: 'pending' | 'approved' | 'rejected' | 'expired' | 'revoked';
    readonly expectedVersion: number;
    readonly version: number;
    readonly authorizationVersion: AuthEpoch;
}
export interface ResultFileIntent {
    readonly intentId?: string;
    readonly fileId?: string;
    readonly versionId?: string;
    readonly businessReference: BusinessReference;
    readonly sourceAppId: string;
    readonly purpose: CollaborationPurpose;
    readonly permission: string;
    readonly authorizationMode: AuthorizationMode;
    readonly authorizationVersion: AuthEpoch;
    readonly status: 'pending' | 'available' | 'revoked' | 'expired';
    readonly expiresAt?: string;
}
export interface NotificationReference {
    readonly notificationId: string;
    readonly stableKey: string;
    readonly kind: string;
    readonly businessReference: BusinessReference;
    readonly permission: string;
    readonly purposes: readonly CollaborationPurpose[];
    readonly authorizationVersion: AuthEpoch;
    readonly readAt: string | null;
}
export interface CreateBusinessEventInput {
    readonly eventVersion: number;
    readonly type: string;
    readonly operationId: string;
    readonly businessReference: BusinessReference;
    readonly occurredAt: string;
    readonly traceId: string;
    readonly data: Readonly<Record<string, unknown>>;
}
export interface CreateApprovalInput {
    readonly businessReference: BusinessReference;
    readonly actionHash: string;
    readonly requestedBy?: string;
    readonly permission: string;
    readonly purposes: readonly CollaborationPurpose[];
    readonly authorizationMode: AuthorizationMode;
    readonly expectedVersion?: number;
}
export interface DecideApprovalInput {
    readonly decision: 'approved' | 'rejected';
    readonly expectedVersion: number;
    readonly actionHash: string;
}
export interface CreateResultFileIntentInput {
    readonly fileId?: string;
    readonly versionId?: string;
    readonly businessReference: BusinessReference;
    readonly sourceAppId: string;
    readonly purpose: CollaborationPurpose;
    readonly permission: string;
    readonly authorizationMode: AuthorizationMode;
    readonly expiresAt?: string;
}
export interface CoordinationPage<T> {
    readonly items: readonly T[];
    readonly nextCursor: string | null;
}
export interface CoordinationEventPage extends CoordinationPage<BusinessEventEnvelope> {
}
export interface ApprovalPage extends CoordinationPage<ApprovalReference> {
}
export interface ResultFileIntentPage extends CoordinationPage<ResultFileIntent> {
}
export declare function parseCollaborationBusinessReference(value: unknown, path?: string): BusinessReference;
export declare function parseCollaborationPolicy(value: unknown, path?: string): CollaborationPolicy;
export declare function parseCollaborationAuthorizationResult(value: unknown, path?: string): CollaborationAuthorizationResult;
export declare function assertCollaborationCommand(value: CollaborationCommand): void;
export declare function parseBusinessEvent(value: unknown, path?: string): BusinessEventEnvelope;
export declare function parseCoordinationTaskReference(value: unknown, path?: string): CoordinationTaskReference;
export declare function parseApprovalReference(value: unknown, path?: string): ApprovalReference;
export declare function parseResultFileIntent(value: unknown, path?: string): ResultFileIntent;
export declare function parseNotificationReference(value: unknown, path?: string): NotificationReference;
export declare function parseCreateBusinessEventInput(value: unknown, path?: string): CreateBusinessEventInput;
export declare function parseCreateApprovalInput(value: unknown, path?: string): CreateApprovalInput;
export declare function parseDecideApprovalInput(value: unknown, path?: string): DecideApprovalInput;
export declare function parseCreateResultFileIntentInput(value: unknown, path?: string): CreateResultFileIntentInput;
export declare function assertCrossTenantOrApplicationDenied(reference: unknown, scope: {
    readonly tenantId: string;
    readonly appId: string;
}): void;
