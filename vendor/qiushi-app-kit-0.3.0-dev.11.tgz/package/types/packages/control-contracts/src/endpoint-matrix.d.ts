export type ContractDomain = 'customer' | 'operations';
export type MatrixRow = Readonly<{
    domain: ContractDomain;
    method: 'GET' | 'POST' | 'PUT' | 'PATCH';
    path: string;
    operationId: string;
    clientMethod: string;
    successStatus: number;
    successSchema: string;
    permission: string;
    pagination: boolean;
    csrf: boolean;
    idempotency: boolean;
    cas: 'none' | 'expectedVersion' | 'expectedConfigVersion' | 'expectedStateVersion' | 'expectedAuthorizationVersion';
}>;
/** Single source of truth used by tests and the local contract-only adapter. */
export declare const endpointMatrix: readonly MatrixRow[];
