export declare const CAPABILITY_KINDS: readonly ["skill", "tool", "expert", "connector", "automation", "knowledge", "runtime-plugin"];
export type CapabilityKind = typeof CAPABILITY_KINDS[number];
export type CapabilityVisibility = 'visible' | 'internal' | 'admin';
export type CapabilityStatus = 'published' | 'revoked';
export interface CapabilityDependency {
    readonly id: string;
    readonly version: string;
    readonly digest: string;
}
export interface CapabilityRecord {
    readonly id: string;
    readonly kind: CapabilityKind;
    readonly version: string;
    readonly source: 'official';
    readonly digest: string;
    readonly inputSchema?: string;
    readonly outputSchema?: string;
    readonly permissions: readonly string[];
    readonly dataPurposes: readonly string[];
    readonly runtimeBaseline: string;
    readonly dependencies: readonly CapabilityDependency[];
    readonly visibility: CapabilityVisibility;
    readonly status: CapabilityStatus;
}
export interface ManifestCapabilityDependency {
    readonly id: string;
    readonly version: string;
    readonly required?: boolean;
    readonly purposes?: readonly string[];
}
export interface CapabilityLockEntry {
    readonly id: string;
    readonly version: string;
    readonly digest: string;
    readonly permissions: readonly string[];
    readonly dataPurposes: readonly string[];
    readonly required: boolean;
    readonly requestedPurposes: readonly string[];
}
export interface CapabilityLock {
    readonly registryVersion: 1;
    readonly entries: readonly CapabilityLockEntry[];
}
export declare const CAPABILITY_REGISTRY_SCHEMA = "https://qiushi.local/schemas/capability-registry-v1.json";
