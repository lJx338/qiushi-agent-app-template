export type DataPurpose = 'ui' | 'model' | 'export' | 'external-action';
export type DataAccessMode = 'tenant-shared' | 'delegated-user';
export type DataOperation = 'list' | 'get' | 'create' | 'update';
export interface DataFieldRequirement {
    readonly name: string;
    readonly type: 'string' | 'integer' | 'decimal-string' | 'boolean' | 'date-time' | 'json';
    readonly required: boolean;
    readonly purposes: readonly DataPurpose[];
}
/** A release declares logical data needs; it never names a tenant's table or token. */
export interface DataDependencyContract {
    readonly logicalName: string;
    readonly contractVersion: string;
    readonly required: boolean;
    readonly operations: readonly DataOperation[];
    readonly fields: readonly DataFieldRequirement[];
    readonly accessMode: DataAccessMode;
    readonly purposes: readonly DataPurpose[];
}
export type DataBindingState = 'configuring' | 'validating' | 'enabled' | 'needs-attention' | 'disabled';
export interface DataBindingRef {
    readonly bindingId: string;
    readonly tenantId: string;
    readonly logicalName: string;
    readonly providerId: string;
    readonly state: DataBindingState;
    readonly mappingVersion: number;
}
export interface DataRecord {
    readonly logicalName: string;
    readonly recordId: string;
    readonly rowVersion: string;
    readonly fields: Readonly<Record<string, unknown>>;
}
