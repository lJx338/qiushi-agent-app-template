/** Public logical resources supported by the first read-only connector contract. */
export declare const DATA_SOURCE_LOGICAL_RESOURCES: readonly ["inquiry", "customer", "material", "attachment-metadata", "historical-quote"];
export type DataSourceLogicalResource = typeof DATA_SOURCE_LOGICAL_RESOURCES[number];
export type DataSourceAccessMode = 'tenant-shared' | 'user-delegated';
export type DataSourceOperation = 'list' | 'get';
export type DataSourcePurpose = 'ui' | 'model' | 'export';
export type DataSourceBindingState = 'configuring' | 'validating' | 'enabled' | 'needs-attention' | 'disabled';
export type DataSourceAuthorizationState = 'authorized' | 'forbidden' | 'revoked';
export type DataSourceDecision = 'allowed' | 'forbidden' | 'revoked' | 'cross-tenant' | 'field-forbidden' | 'purpose-forbidden' | 'stale' | 'rate-limited' | 'drift' | 'unavailable' | 'unsupported';
export type DataSourceFieldType = 'string' | 'integer' | 'decimal-string' | 'boolean' | 'date-time';
export interface DataSourceFieldDescriptor {
    readonly logicalField: string;
    readonly sourceField: string;
    readonly type: DataSourceFieldType;
    readonly required: boolean;
    /** A field can be returned only for a purpose explicitly listed here. */
    readonly purposes: readonly DataSourcePurpose[];
}
export interface DataSourceResourceCapability {
    readonly logicalResource: DataSourceLogicalResource;
    readonly operations: readonly DataSourceOperation[];
    readonly accessModes: readonly DataSourceAccessMode[];
    readonly fields: readonly DataSourceFieldDescriptor[];
    readonly readOnly: true;
    readonly pagination: {
        readonly style: 'cursor';
        readonly maxPageSize: number;
    };
    readonly maxStaleSeconds: number;
}
export type ProviderCapability = DataSourceResourceCapability;
export type LogicalResourceMapping = DataSourceResourceCapability;
export interface DataSourceDescriptor {
    readonly descriptorVersion: 'qiushi.data-source.v1';
    readonly providerId: string;
    readonly displayName: string;
    readonly readOnly: true;
    readonly tokenHandling: 'platform-managed';
    readonly capabilities: readonly DataSourceResourceCapability[];
    readonly rejectionPolicy: {
        readonly writes: 'reject';
        readonly arbitrarySourceReads: 'reject';
        readonly crossTenant: 'reject';
    };
}
export interface DataSourceSourceIdentity {
    readonly mode: DataSourceAccessMode;
    /** Opaque platform reference; never a token or source credential. */
    readonly subjectRef?: string;
    readonly label?: string;
}
export interface DataSourceFieldMapping extends DataSourceFieldDescriptor {
}
export type LogicalFieldMapping = DataSourceFieldMapping;
export interface DataSourceBinding {
    readonly bindingId: string;
    readonly tenantId: string;
    readonly workspaceId?: string;
    readonly providerId: string;
    readonly logicalResource: DataSourceLogicalResource;
    readonly accessMode: DataSourceAccessMode;
    readonly sourceIdentity: DataSourceSourceIdentity;
    readonly purposes: readonly DataSourcePurpose[];
    readonly mappings: readonly DataSourceFieldMapping[];
    readonly state: DataSourceBindingState;
    readonly mappingVersion: number;
    readonly authorizationVersion: string;
    readonly maxStaleSeconds: number;
}
/** Trusted platform context. Applications and models cannot construct or alter it. */
export interface DataSourceQueryContext {
    readonly tenantId: string;
    readonly workspaceId?: string;
    readonly actorId: string;
    readonly appId: string;
    readonly installationId: string;
    readonly authorizationVersion: string;
}
/** No tenant, workspace, table, record URL, token, or credential is accepted from an app. */
export interface DataSourceQueryRequest {
    readonly bindingId: string;
    readonly logicalResource: DataSourceLogicalResource;
    readonly operation: DataSourceOperation;
    readonly purpose: DataSourcePurpose;
    readonly fields: readonly string[];
    readonly sourceRecordId?: string;
    readonly cursor?: string | null;
    readonly limit?: number;
}
export interface DataSourceRecord {
    readonly recordId: string;
    readonly sourceRecordId: string;
    readonly sourceRowVersion: string;
    readonly fields: Readonly<Record<string, string | number | boolean>>;
    readonly sourceIdentity: DataSourceSourceIdentity;
    readonly sourceDigest: string;
    readonly observedAt: string;
}
export interface DataSourcePage {
    readonly logicalResource: DataSourceLogicalResource;
    readonly records: readonly DataSourceRecord[];
    readonly nextCursor: string | null;
    readonly sourceDigest: string;
    readonly fetchedAt: string;
    readonly staleAt: string;
    readonly fromCache: boolean;
}
export interface DataSourceAuditContext {
    readonly tenantId: string;
    readonly actorId: string;
    readonly bindingId: string;
    readonly providerId: string;
    readonly logicalResource: DataSourceLogicalResource;
    readonly operation: DataSourceOperation;
    readonly purpose: DataSourcePurpose;
    readonly accessMode: DataSourceAccessMode;
    readonly sourceIdentity: DataSourceSourceIdentity;
    readonly authorizationVersion: string;
    readonly sourceDigest?: string;
}
export interface DataSourceErrorShape {
    readonly decision: Exclude<DataSourceDecision, 'allowed'>;
    readonly retryable: boolean;
    readonly invalidateCache: boolean;
    readonly message?: string;
}
export declare class DataSourceContractError extends Error {
    readonly decision: Exclude<DataSourceDecision, 'allowed'>;
    readonly retryable: boolean;
    readonly invalidateCache: boolean;
    constructor(decision: Exclude<DataSourceDecision, 'allowed'>, message?: string, retryable?: boolean, invalidateCache?: boolean);
}
export declare function parseDataSourceError(value: unknown, path?: string): DataSourceErrorShape;
export interface ReadOnlyDataSourceProvider {
    readonly descriptor: DataSourceDescriptor;
    inspect(binding: DataSourceBinding, context: DataSourceQueryContext): Promise<DataSourceAuthorizationState>;
    query(request: DataSourceQueryRequest, binding: DataSourceBinding, context: DataSourceQueryContext): Promise<DataSourcePage>;
}
export interface ReadOnlyDataSourcePort {
    query(request: DataSourceQueryRequest): Promise<DataSourcePage>;
}
export type DataSourceQueryPort = ReadOnlyDataSourcePort;
export type ReadOnlyQueryRequest = DataSourceQueryRequest;
export type ReadOnlyQueryPage = DataSourcePage;
export declare function parseDataSourceFieldDescriptor(value: unknown, path?: string): DataSourceFieldDescriptor;
export declare function parseDataSourceDescriptor(value: unknown, path?: string): DataSourceDescriptor;
export declare function parseDataSourceBinding(value: unknown, path?: string): DataSourceBinding;
export declare function parseDataSourceQueryRequest(value: unknown, path?: string): DataSourceQueryRequest;
export declare function assertReadOnlyQueryAllowed(request: DataSourceQueryRequest, binding: DataSourceBinding, context: DataSourceQueryContext, descriptor: DataSourceDescriptor): void;
export declare function assertNoCredentialOrDirectReference(value: unknown): void;
export declare function parseDataSourcePage(value: unknown, path?: string): DataSourcePage;
/** Matrix frozen by V6-Q0: Feishu is read-only and rejects all external writes. */
export declare const FEISHU_READ_ONLY_REJECTIONS: readonly ["write-back-quote", "send-message", "start-approval", "arbitrary-table-read"];
