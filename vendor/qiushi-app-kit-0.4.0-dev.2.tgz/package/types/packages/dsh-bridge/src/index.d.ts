import type { Context } from '@deepseek-ai/cordis';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import { type AppDefinition, type Json } from '../../app-sdk/src/index.ts';
import { type ActionExecutionRequest, type ActionExecutor } from '../../control-contracts/src/action-execution.ts';
/** Production provider is NOT implemented by the development executor. */
export interface BusinessProvider {
    execute(app: AppDefinition, actionId: string, input: Json, execution: ToolRunContext): Promise<Json>;
}
/**
 * Compatibility adapter for a future DSH tool host. It adds no DSH runtime
 * behavior: the host supplies a request factory and receives the same receipt
 * as Edge/control-plane callers. A provider cannot return a result by
 * bypassing ActionExecutor.
 */
export declare function createActionExecutionBusinessProvider(executor: ActionExecutor, requestFor: (app: AppDefinition, actionId: string, input: Json, execution: ToolRunContext) => ActionExecutionRequest): BusinessProvider;
declare module '@deepseek-ai/cordis' {
    interface Context {
        qsBusiness: BusinessProvider;
    }
}
/** Register raw DSH tools; DSH owns registration lifetime and native execution. */
export declare function registerDshApp(ctx: Context, app: AppDefinition): void;
