import { ContractValidationError } from './runtime.ts';
export declare const ONTOLOGY_REFERENCE_VERSION: "qiushi.ontology-reference.v1";
export declare const ONTOLOGY_RELATION_VERSION: "qiushi.ontology-relation.v1";
export declare const ONTOLOGY_ANCHOR_VERSION: "qiushi.ontology-anchor.v1";
export declare const ONTOLOGY_CORE_NAMESPACE: {
    readonly layer: "platform-core";
    readonly namespace: "qiushi.core";
    readonly owner: "qiushi.platform";
};
export declare const ONTOLOGY_CORE_TYPES: readonly ["Customer", "Quote", "Task", "Approval", "KnowledgeDocument"];
export declare const ONTOLOGY_SOURCE_KINDS: readonly ["platform", "local-provider", "external-mcp"];
export declare const ONTOLOGY_ANCHOR_KINDS: readonly ["action-input", "action-output", "event", "task", "approval", "knowledge", "file-intent", "collaboration"];
export declare const ONTOLOGY_PURPOSES: readonly ["ui", "model", "export", "external-action"];
export type OntologyNamespaceLayerV1 = 'platform-core' | 'industry-extension' | 'application-extension';
export type OntologySourceKindV1 = typeof ONTOLOGY_SOURCE_KINDS[number];
export type OntologyAnchorKindV1 = typeof ONTOLOGY_ANCHOR_KINDS[number];
export type OntologyPurposeV1 = typeof ONTOLOGY_PURPOSES[number];
export type OntologyErrorCode = 'ONTOLOGY_CONTRACT_INVALID' | 'ONTOLOGY_FORBIDDEN_FIELD' | 'ONTOLOGY_NAMESPACE_UNSUPPORTED' | 'ONTOLOGY_TYPE_UNSUPPORTED' | 'ONTOLOGY_VERSION_UNSUPPORTED' | 'ONTOLOGY_SOURCE_INVALID' | 'ONTOLOGY_RELATION_INVALID' | 'ONTOLOGY_CROSS_TENANT' | 'ONTOLOGY_CROSS_APPLICATION' | 'ONTOLOGY_PERMISSION_FORBIDDEN' | 'ONTOLOGY_FIELD_FORBIDDEN' | 'ONTOLOGY_PURPOSE_FORBIDDEN' | 'ONTOLOGY_SOURCE_FORBIDDEN';
export declare class OntologyContractError extends ContractValidationError {
    readonly code: OntologyErrorCode;
    constructor(code: OntologyErrorCode, message: string, path?: string);
}
export interface OntologyNamespaceV1 {
    readonly layer: OntologyNamespaceLayerV1;
    readonly namespace: string;
    readonly owner: string;
}
export interface OntologySourceBindingV1 {
    readonly kind: OntologySourceKindV1;
    /** Stable logical binding identity. It is not a connection string or provider configuration. */
    readonly bindingId: string;
    /** Opaque record identity within the authorized binding. It is not a table, column, URL, or path. */
    readonly recordId: string;
}
export interface OntologyReferenceV1 {
    readonly referenceVersion: typeof ONTOLOGY_REFERENCE_VERSION;
    readonly namespace: OntologyNamespaceV1;
    readonly type: string;
    readonly version: string;
    readonly id: string;
    readonly source: OntologySourceBindingV1;
}
export interface OntologyTypeDefinitionV1 {
    readonly namespace: OntologyNamespaceV1;
    readonly type: string;
    readonly versions: readonly string[];
}
export interface OntologyTypeSelectorV1 {
    readonly namespace: string;
    readonly type: string;
}
export interface OntologyRelationDefinitionV1 {
    readonly namespace: OntologyNamespaceV1;
    readonly type: string;
    readonly versions: readonly string[];
    readonly from: OntologyTypeSelectorV1;
    readonly to: OntologyTypeSelectorV1;
}
export interface OntologyCatalogV1 {
    readonly types: readonly OntologyTypeDefinitionV1[];
    readonly relations: readonly OntologyRelationDefinitionV1[];
}
export interface OntologyRelationV1 {
    readonly relationVersion: typeof ONTOLOGY_RELATION_VERSION;
    readonly namespace: OntologyNamespaceV1;
    readonly type: string;
    readonly version: string;
    readonly id: string;
    readonly from: OntologyReferenceV1;
    readonly to: OntologyReferenceV1;
}
export interface OntologyReferenceAnchorV1 {
    readonly anchorVersion: typeof ONTOLOGY_ANCHOR_VERSION;
    readonly kind: OntologyAnchorKindV1;
    readonly reference: OntologyReferenceV1;
    readonly relatedReferences?: readonly OntologyReferenceV1[];
}
export type OntologyActionInputV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'action-input';
};
export type OntologyActionOutputV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'action-output';
};
export type OntologyEventV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'event';
};
export type OntologyTaskV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'task';
};
export type OntologyApprovalV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'approval';
};
export type OntologyKnowledgeV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'knowledge';
};
export type OntologyFileIntentV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'file-intent';
};
export type OntologyCollaborationV1 = OntologyReferenceAnchorV1 & {
    readonly kind: 'collaboration';
};
export interface OntologyAccessRequestV1 {
    readonly permission: string;
    readonly fields: readonly string[];
    readonly purpose: OntologyPurposeV1;
}
/** Ownership facts returned by a trusted resolver. They are never accepted from the reference. */
export interface OntologyResolvedScopeV1 {
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly sourceBindingId: string;
}
/** Trusted authorization context assembled from current installation, employee, field, purpose, and source grants. */
export interface OntologyAuthorizationContextV1 {
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly installationId: string;
    readonly actorId: string;
    readonly applicationId: string;
    readonly permissions: readonly string[];
    readonly fields: readonly string[];
    readonly purposes: readonly OntologyPurposeV1[];
    readonly sourceBindingIds: readonly string[];
    readonly delegatedApplicationIds: readonly string[];
}
export declare const CORE_ONTOLOGY_CATALOG_V1: OntologyCatalogV1;
export declare function parseOntologyNamespaceV1(value: unknown, path?: string): OntologyNamespaceV1;
export declare function parseOntologySourceBindingV1(value: unknown, path?: string): OntologySourceBindingV1;
export declare function parseOntologyTypeDefinitionV1(value: unknown, path?: string): OntologyTypeDefinitionV1;
export declare function parseOntologyRelationDefinitionV1(value: unknown, path?: string): OntologyRelationDefinitionV1;
export declare function parseOntologyCatalogV1(value: unknown): OntologyCatalogV1;
export declare function parseOntologyReferenceV1(value: unknown, catalogValue?: OntologyCatalogV1, path?: string): OntologyReferenceV1;
export declare function parseOntologyRelationV1(value: unknown, catalogValue?: OntologyCatalogV1, path?: string): OntologyRelationV1;
export declare function parseOntologyReferenceAnchorV1(value: unknown, catalogValue?: OntologyCatalogV1, path?: string): OntologyReferenceAnchorV1;
export declare function assertOntologyReferenceAuthorized(reference: OntologyReferenceV1, resolved: OntologyResolvedScopeV1, request: OntologyAccessRequestV1, context: OntologyAuthorizationContextV1): void;
