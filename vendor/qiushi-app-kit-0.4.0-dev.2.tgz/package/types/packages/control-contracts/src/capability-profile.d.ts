import { ContractValidationError } from './runtime.ts';
import type { CapabilityKind, CapabilityRecord, CapabilitySource } from './capabilities.ts';
export type { CapabilitySource } from './capabilities.ts';
export declare const CAPABILITY_DESCRIPTOR_VERSION: "qiushi.capability.v1";
export declare const EDGE_RUNTIME_PROFILE_VERSION: "qiushi.edge-runtime-profile.v1";
export declare const CAPABILITY_LOCK_VERSION: "qiushi.capability-lock.v1";
export declare const CAPABILITY_REGISTRY_VERSION: 2;
export declare const CAPABILITY_SOURCES: readonly ["official", "developer", "customer-private"];
export declare const CAPABILITY_RISK_LEVELS: readonly ["read-only", "business-write", "external-side-effect"];
export declare const CAPABILITY_PURPOSES: readonly ["ui", "model", "export", "external-action"];
export type CapabilityRiskLevel = typeof CAPABILITY_RISK_LEVELS[number];
export type CapabilityPurpose = typeof CAPABILITY_PURPOSES[number];
export type CapabilityErrorCode = 'CAPABILITY_CONTRACT_INVALID' | 'CAPABILITY_UNDECLARED' | 'CAPABILITY_SIGNATURE_REQUIRED' | 'CAPABILITY_SIGNATURE_INVALID' | 'CAPABILITY_QUARANTINE_REQUIRED' | 'CAPABILITY_REVOKED' | 'CAPABILITY_DIGEST_MISMATCH' | 'CAPABILITY_PERMISSION_EXPANSION' | 'CAPABILITY_PURPOSE_EXPANSION' | 'CAPABILITY_RUNTIME_INCOMPATIBLE' | 'CAPABILITY_PROFILE_UNSATISFIED' | 'CAPABILITY_RESOURCE_UNBOUNDED' | 'CAPABILITY_LOCK_INCOMPLETE' | 'CAPABILITY_DEPENDENCY_CYCLE';
export declare class CapabilityContractError extends ContractValidationError {
    readonly code: CapabilityErrorCode;
    constructor(code: CapabilityErrorCode, message: string, path?: string);
}
export interface CapabilityTrust {
    readonly signature: {
        readonly status: 'verified' | 'unsigned' | 'invalid';
        readonly keyId?: string;
        readonly digest?: string;
    };
    readonly quarantine: {
        readonly status: 'passed' | 'pending' | 'rejected';
        readonly policyVersion: string;
        readonly checkedAt: string;
    };
}
export type RuntimeEntryType = 'mcp-server' | 'provider' | 'dsh-plugin' | 'worker';
export interface EdgeRuntimeProfile {
    readonly profileVersion: typeof EDGE_RUNTIME_PROFILE_VERSION;
    readonly runtime: {
        readonly name: 'qiushi-edge';
        readonly versionRange: string;
    };
    readonly dsh: {
        readonly revision: string;
    };
    readonly node: {
        readonly versionRange: string;
    };
    readonly cordis: {
        readonly versionRange: string;
    };
    readonly entrypoints: readonly {
        readonly type: RuntimeEntryType;
        readonly entry: string;
    }[];
    readonly resources: {
        readonly network: {
            readonly mode: 'none' | 'allowlist';
            readonly hosts: readonly string[];
        };
        readonly filesystem: {
            readonly mode: 'none' | 'read-only' | 'read-write';
            readonly roots: readonly string[];
        };
        readonly credentials: {
            readonly mode: 'none' | 'brokered';
            readonly brokerIds: readonly string[];
        };
        readonly devices: {
            readonly mode: 'none' | 'allowlist';
            readonly ids: readonly string[];
        };
        readonly limits: {
            readonly cpuMillicores: number;
            readonly memoryMiB: number;
            readonly maxConcurrency: number;
        };
    };
}
export interface EdgeRuntimeEnvironment {
    readonly runtimeVersion: string;
    readonly dshRevision: string;
    readonly nodeVersion: string;
    readonly cordisVersion: string;
    readonly entryTypes: readonly RuntimeEntryType[];
    readonly networkHosts: readonly string[];
    readonly filesystem: {
        readonly mode: 'none' | 'read-only' | 'read-write';
        readonly roots: readonly string[];
    };
    readonly credentialBrokerIds: readonly string[];
    readonly deviceIds: readonly string[];
    readonly limits: {
        readonly cpuMillicores: number;
        readonly memoryMiB: number;
        readonly maxConcurrency: number;
    };
}
export interface ResolvedCapabilityDependency {
    readonly version: string;
    readonly digest: string;
}
export interface CapabilityDescriptor extends Omit<CapabilityRecord, 'runtimeBaseline' | 'dependencies' | 'dataPurposes'> {
    readonly contractVersion: typeof CAPABILITY_DESCRIPTOR_VERSION;
    readonly trust: CapabilityTrust;
    readonly risk: CapabilityRiskLevel;
    readonly dataPurposes: readonly CapabilityPurpose[];
    readonly runtimeProfile: EdgeRuntimeProfile;
    readonly dependencies: Readonly<Record<string, ResolvedCapabilityDependency>>;
}
export type CapabilityRegistryEntry = Omit<CapabilityDescriptor, 'id' | 'version'>;
export interface CapabilityRegistryV2 {
    readonly registryVersion: typeof CAPABILITY_REGISTRY_VERSION;
    readonly capabilities: Readonly<Record<string, CapabilityRegistryEntry>>;
}
export interface CapabilityRequirement {
    readonly versionRange: string;
    readonly required: boolean;
    readonly purposes: readonly CapabilityPurpose[];
}
export type CapabilityRequirements = Readonly<Record<string, CapabilityRequirement>>;
export interface CapabilityLockV1Entry {
    readonly kind: CapabilityKind;
    readonly version: string;
    readonly digest: string;
    readonly source: CapabilitySource;
    readonly trust: CapabilityTrust;
    readonly risk: CapabilityRiskLevel;
    readonly permissions: readonly string[];
    readonly purposes: readonly CapabilityPurpose[];
    readonly requestedPurposes: readonly CapabilityPurpose[];
    readonly required: boolean;
    readonly direct: boolean;
    readonly runtimeProfile: EdgeRuntimeProfile;
    readonly dependencies: Readonly<Record<string, ResolvedCapabilityDependency>>;
}
export interface CapabilityLockV1 {
    readonly formatVersion: typeof CAPABILITY_LOCK_VERSION;
    readonly registryVersion: typeof CAPABILITY_REGISTRY_VERSION;
    readonly entries: Readonly<Record<string, CapabilityLockV1Entry>>;
}
export interface CapabilityLockValidationContext {
    readonly registry: unknown;
    readonly environment: EdgeRuntimeEnvironment;
    readonly requirements: unknown;
    readonly appPermissions: readonly string[];
}
export declare const CAPABILITY_RISK_POLICIES: {
    readonly 'read-only': {
        readonly effect: "none";
        readonly allowedPurposes: readonly ["ui", "model", "export"];
        readonly authorizationRecheck: "before-dispatch-and-before-result";
        readonly idempotency: "optional";
        readonly unknownOutcome: "failed";
    };
    readonly 'business-write': {
        readonly effect: "business-write";
        readonly allowedPurposes: readonly ["ui", "model", "external-action"];
        readonly authorizationRecheck: "before-dispatch-and-before-result";
        readonly idempotency: "required";
        readonly unknownOutcome: "reconciling";
    };
    readonly 'external-side-effect': {
        readonly effect: "business-write";
        readonly allowedPurposes: readonly ["external-action"];
        readonly authorizationRecheck: "before-dispatch-and-before-result";
        readonly idempotency: "required";
        readonly unknownOutcome: "reconciling";
    };
};
export declare function parseCapabilityTrust(value: unknown, path?: string): CapabilityTrust;
export declare function parseEdgeRuntimeProfile(value: unknown, path?: string): EdgeRuntimeProfile;
export declare function parseCapabilityDescriptor(value: unknown, path?: string): CapabilityDescriptor;
export declare function capabilityDescriptors(registry: CapabilityRegistryV2): CapabilityDescriptor[];
export declare function toLegacyCapabilityRecord(capability: CapabilityDescriptor): CapabilityRecord;
export declare function parseCapabilityRegistryV2(value: unknown): CapabilityRegistryV2;
export declare function parseCapabilityRequirements(value: unknown): CapabilityRequirements;
export declare function parseCapabilityRequirement(value: unknown, path?: string): CapabilityRequirement;
export declare function assertCapabilityUsable(capability: CapabilityDescriptor, path?: string): void;
export declare function satisfiesCapabilityVersion(version: string, range: string): boolean;
export declare function assertRuntimeProfileSatisfied(profile: EdgeRuntimeProfile, environment: EdgeRuntimeEnvironment, path?: string): void;
export declare function resolveCapabilityLockV1(requirementsValue: unknown, registryValue: unknown, environment: EdgeRuntimeEnvironment, appPermissions: readonly string[]): CapabilityLockV1;
export declare function parseCapabilityLockV1(value: unknown): CapabilityLockV1;
export declare function validateCapabilityLockV1(value: unknown, context: CapabilityLockValidationContext): CapabilityLockV1;
export declare function assertCapabilityInvocation(lockValue: unknown, capabilityIdValue: string, permissionsValue: readonly string[], purposesValue: readonly CapabilityPurpose[], context: CapabilityLockValidationContext): CapabilityLockV1Entry;
