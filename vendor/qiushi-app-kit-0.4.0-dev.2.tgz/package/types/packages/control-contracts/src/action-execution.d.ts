/** Shared, runtime-neutral protocol used by Edge and cloud control-plane action dispatch. */
export declare const ACTION_EXECUTION_PROTOCOL_VERSION: "qiushi.action-execution.v1";
export type ActionExecutionOrigin = 'edge' | 'cloud-control';
export type ActionExecutionDecision = 'allowed' | 'forbidden' | 'revoked' | 'cross-tenant';
export type ActionExecutionState = 'succeeded' | 'failed' | 'forbidden' | 'revoked' | 'unknown' | 'reconciling';
export interface ActionExecutionScope {
    readonly actorId: string;
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly installationId: string;
}
export interface ActionExecutionRequest {
    readonly protocolVersion: typeof ACTION_EXECUTION_PROTOCOL_VERSION;
    readonly origin: ActionExecutionOrigin;
    /** Stable caller-generated operation identifier. It is not a run or task identifier. */
    readonly operationId: string;
    readonly idempotencyKey: string;
    readonly actionId: string;
    readonly scope: ActionExecutionScope;
    readonly input: unknown;
}
export interface ActionExecutionAuthorization {
    readonly decision: ActionExecutionDecision;
    readonly reasonCode: string;
    /** Current membership/install authorization epoch, if a decision could be made. */
    readonly authorizationVersion?: string;
}
export interface ActionExecutionAuditEvent {
    readonly request: ActionExecutionRequest;
    readonly stage: 'authorization' | 'replay' | 'dispatch' | 'completion';
    readonly decision: ActionExecutionDecision | 'unknown';
    readonly state?: ActionExecutionState;
    readonly reasonCode?: string;
    /** True means an external provider may have completed work before a revocation or transport failure. */
    readonly sideEffectMayHaveOccurred: boolean;
}
export interface ActionExecutionReceipt {
    readonly protocolVersion: typeof ACTION_EXECUTION_PROTOCOL_VERSION;
    readonly operationId: string;
    readonly idempotencyKey: string;
    readonly inputFingerprint: string;
    readonly scope: ActionExecutionScope;
    readonly actionId: string;
    readonly origin: ActionExecutionOrigin;
    readonly state: ActionExecutionState;
    readonly decision: ActionExecutionDecision | 'unknown';
    readonly reasonCode?: string;
    readonly authorizationVersion?: string;
    readonly auditId: string;
    readonly output?: unknown;
}
export interface ActionExecutionAuthorizer {
    authorize(request: ActionExecutionRequest): Promise<ActionExecutionAuthorization>;
}
export interface ActionExecutionProvider {
    execute(request: ActionExecutionRequest): Promise<unknown>;
}
export interface ActionExecutionReceiptStore {
    /**
     * Atomically creates or observes one operation identity. The implementation
     * must fence `complete` by leaseId and reject a different payload/scope for
     * an existing key, including while the first caller is still in flight.
     */
    claim(request: ActionExecutionRequest, inputFingerprint: string): Promise<ActionExecutionClaim>;
    complete(claim: ActionExecutionLease, receipt: ActionExecutionReceipt): Promise<void>;
}
export interface ActionExecutionLease {
    readonly kind: 'claimed';
    readonly leaseId: string;
}
export type ActionExecutionClaim = ActionExecutionLease | {
    readonly kind: 'terminal';
    readonly receipt: ActionExecutionReceipt;
} | {
    readonly kind: 'pending';
    awaitTerminal(): Promise<ActionExecutionReceipt>;
};
export interface ActionExecutionAuditPort {
    record(event: ActionExecutionAuditEvent): Promise<{
        readonly auditId: string;
    }>;
}
export declare class ActionExecutionUnknownError extends Error {
    readonly code: string;
    constructor(code?: string);
}
export declare class ActionExecutionError extends Error {
    readonly code: string;
    constructor(code: string);
}
export interface ActionExecutorOptions {
    readonly authorizer: ActionExecutionAuthorizer;
    readonly receipts: ActionExecutionReceiptStore;
    readonly audit: ActionExecutionAuditPort;
    /** Omit when a selected runtime/provider is unavailable; the request then fails closed. */
    readonly provider?: ActionExecutionProvider;
}
/**
 * The only dispatch state machine shared by Edge and cloud adapters. It owns
 * no run/task state: durable state is solely the operation receipt supplied by
 * the host store. A receipt is never replayed until current authorization is
 * checked again, so revocation cannot expose an old result.
 */
export declare class ActionExecutor {
    private readonly options;
    constructor(options: ActionExecutorOptions);
    execute(request: ActionExecutionRequest): Promise<ActionExecutionReceipt>;
    private complete;
    private rejectedReplay;
}
export declare function assertActionExecutionRequest(request: ActionExecutionRequest): void;
/** Stable, non-secret canonical value for receipt-store conflict detection. Stores may hash it at rest. */
export declare function actionExecutionInputFingerprint(value: unknown): string;
