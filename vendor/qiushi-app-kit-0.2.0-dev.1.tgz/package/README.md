# Qiushi 独立应用开发包

平台维护的 SDK、DSH bridge、合成数据及 CLI。导出主契约、development 测试入口和 dsh 桥接入口，业务源码不得引入 development。

源码与 monorepo 工具共用，发布构建时生成 JS、类型声明与开发资源，不包含平台业务页面、生产服务或凭证。本版本通过 npm tgz 随私有模板受控分发，未发布公共 npm registry。版本与 package-lock integrity 固定，升级由平台重新发布；不编辑 node_modules。

CLI：check、test、run、dev、build、pack、typecheck、verify；create 创建新的独立应用目录。全部为 development，不能提供真实 DSH Client、认证、持久业务或后台安装。
