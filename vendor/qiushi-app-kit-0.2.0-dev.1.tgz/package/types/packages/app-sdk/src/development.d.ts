import { type ActionDefinition, type BusinessData, type ExecutionContext } from './index.ts';
/** Synthetic data ONLY. Never used by the DSH production host bridge. */
export declare class DevelopmentData {
    private readonly customers;
    private readonly drafts;
    forExecution: (context: ExecutionContext, action: ActionDefinition) => BusinessData;
    countDrafts(tenantId: string): number;
}
export declare function developmentContext(appId: string, appVersion: string, scenario?: string): ExecutionContext;
