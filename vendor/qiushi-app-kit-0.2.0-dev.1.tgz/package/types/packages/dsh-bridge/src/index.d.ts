import type { Context } from '@deepseek-ai/cordis';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import { type AppDefinition, type Json } from '../../app-sdk/src/index.ts';
/** Production provider is NOT implemented by the development executor. */
export interface BusinessProvider {
    execute(app: AppDefinition, actionId: string, input: Json, execution: ToolRunContext): Promise<Json>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        qsBusiness: BusinessProvider;
    }
}
/** Register raw DSH tools; DSH owns registration lifetime and native execution. */
export declare function registerDshApp(ctx: Context, app: AppDefinition): void;
