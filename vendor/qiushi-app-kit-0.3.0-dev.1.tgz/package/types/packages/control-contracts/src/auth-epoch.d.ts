/**
 * Canonical representation of PostgreSQL bigint auth_epoch values.
 *
 * It is intentionally a string: callers must never pass this value through
 * JavaScript Number, whose safe integer range is smaller than PostgreSQL
 * bigint.
 */
export type AuthEpoch = string;
export declare function isAuthEpoch(value: unknown): value is AuthEpoch;
export declare function requireAuthEpoch(value: unknown): AuthEpoch;
