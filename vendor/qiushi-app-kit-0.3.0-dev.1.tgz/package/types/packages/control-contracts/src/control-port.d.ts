import type { AuthEpoch } from './auth-epoch.ts';
export type ActorState = 'active' | 'disabled';
export type TenantState = 'enabled' | 'disabled';
export type MembershipState = 'active' | 'suspended' | 'revoked';
export type WorkspaceState = 'enabled' | 'disabled';
export type InstallationState = 'enabled' | 'disabled';
export type SessionState = 'active' | 'revoked' | 'expired';
declare const browserSessionTokenBrand: unique symbol;
declare const sessionTokenDigestBrand: unique symbol;
/** High-entropy value held only in the browser's HttpOnly session cookie. */
export type BrowserSessionToken = string & {
    readonly [browserSessionTokenBrand]: 'BrowserSessionToken';
};
/** One-way digest persisted by B2; it is never sent to the browser. */
export type SessionTokenDigest = string & {
    readonly [sessionTokenDigestBrand]: 'SessionTokenDigest';
};
export interface IssuerSubject {
    readonly issuer: string;
    readonly subject: string;
}
export interface ActorIdentity extends IssuerSubject {
    readonly actorId: string;
    readonly identityState: 'active' | 'revoked';
    readonly actorState: ActorState;
}
export interface WorkspaceActionGrant {
    readonly workspaceId: string;
    readonly actions: readonly string[];
}
/** The current, minimal state required to decide one registered action. */
export interface LatestActionAuthorizationState {
    readonly actor: {
        readonly id: string;
        readonly state: ActorState;
    };
    readonly tenant: {
        readonly id: string;
        readonly state: TenantState;
    };
    readonly membership: {
        readonly tenantId: string;
        readonly actorId: string;
        readonly state: MembershipState;
        readonly authEpoch: AuthEpoch;
        readonly allowedWorkspaceIds: readonly string[];
        readonly workspaceActionGrants: readonly WorkspaceActionGrant[];
    };
    readonly workspace: {
        readonly id: string;
        readonly tenantId: string;
        readonly state: WorkspaceState;
    };
    readonly installation: {
        readonly id: string;
        readonly tenantId: string;
        readonly workspaceId: string;
        readonly state: InstallationState;
        readonly allowedActions: readonly string[];
    };
    readonly knownActions: readonly string[];
}
export interface ActionStateLookup extends IssuerSubject {
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly installationId: string;
}
export interface VisibleTenantMembership {
    readonly tenantId: string;
    readonly tenantState: TenantState;
    readonly membershipState: MembershipState;
    readonly authEpoch: AuthEpoch;
}
export interface ServerSession {
    readonly sessionId: string;
    readonly actorId: string;
    readonly issuer: string;
    readonly subject: string;
    readonly authenticatedAt: Date;
    readonly expiresAt: Date;
    readonly revokedAt: Date | null;
    readonly state: SessionState;
}
/** B2-only storage shape. It intentionally has no raw browser token field. */
export interface PersistedServerSession extends ServerSession {
    readonly browserSessionTokenDigest: SessionTokenDigest;
}
/**
 * The raw browser token is generated and returned exactly once at creation.
 * C2 sends it directly as an HttpOnly cookie and must not persist or log it.
 */
export interface CreatedBrowserSession {
    readonly browserSessionToken: BrowserSessionToken;
    readonly session: ServerSession;
}
export interface AuthorizationTransaction {
    readonly transactionId: string;
    readonly state: string;
    readonly nonce: string;
    /** Service-only secret; never serialize or log this value. */
    readonly pkceVerifier: string;
    readonly returnPath: string;
    readonly expiresAt: Date;
    readonly consumedAt: Date | null;
}
export type ConsumeAuthorizationTransactionResult = {
    readonly kind: 'consumed';
    readonly transaction: AuthorizationTransaction;
} | {
    readonly kind: 'not-found';
} | {
    readonly kind: 'already-consumed';
} | {
    readonly kind: 'expired';
};
export interface TenantTransactionContext {
    readonly tenantId: string;
    readonly actorId: string;
    readonly authEpoch: AuthEpoch;
}
export interface TenantWorkspace {
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly state: WorkspaceState;
}
/**
 * Only capabilities bound to the transaction's checked-out connection are
 * exposed to a callback. It deliberately does not expose pg PoolClient.
 */
export interface TenantTransactionScope {
    readonly context: TenantTransactionContext;
    readonly workspaces: {
        findWorkspace(workspaceId: string): Promise<TenantWorkspace | null>;
    };
}
/**
 * B2 provides this service-only interface. It must use trusted, already
 * verified identity/session inputs; it is not an HTTP request API.
 */
export interface ControlDataPort {
    findActorByIssuerSubject(input: IssuerSubject): Promise<ActorIdentity | null>;
    listVisibleTenantMemberships(actorId: string): Promise<readonly VisibleTenantMembership[]>;
    getLatestActionAuthorizationState(input: ActionStateLookup): Promise<LatestActionAuthorizationState | null>;
    createSession(input: Omit<ServerSession, 'sessionId' | 'revokedAt' | 'state'>): Promise<CreatedBrowserSession>;
    findSessionByBrowserToken(input: {
        readonly browserSessionToken: BrowserSessionToken;
        readonly now: Date;
    }): Promise<ServerSession | null>;
    revokeSessionByBrowserToken(input: {
        readonly browserSessionToken: BrowserSessionToken;
        readonly revokedAt: Date;
    }): Promise<'revoked' | 'not-found'>;
    createAuthorizationTransaction(input: Omit<AuthorizationTransaction, 'transactionId' | 'consumedAt'>): Promise<AuthorizationTransaction>;
    consumeAuthorizationTransaction(input: {
        readonly transactionId: string;
        readonly state: string;
        readonly now: Date;
    }): Promise<ConsumeAuthorizationTransactionResult>;
    withTenantTransaction<T>(context: TenantTransactionContext, operation: (scope: TenantTransactionScope) => Promise<T>): Promise<T>;
}
export {};
