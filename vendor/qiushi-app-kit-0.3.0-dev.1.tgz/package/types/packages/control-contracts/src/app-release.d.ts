import type { DataDependencyContract, DataPurpose } from './data-foundation.ts';
import type { PlatformUiExtensionDescriptor } from './ui-extension.ts';
export declare const APP_RELEASE_FORMAT_VERSION: "qiushi.app-release.v2";
export interface RuntimeContributionDescriptor {
    readonly kind: 'dsh-patch' | 'dsh-tool' | 'dsh-preset' | 'dsh-workflow';
    readonly entry: string;
    readonly sha256: string;
}
export interface PermissionDeclaration {
    readonly actionId: string;
    readonly purposes: readonly DataPurpose[];
}
/** Immutable release input consumed by validation and installation control planes. */
export interface AppReleaseDescriptorV2 {
    readonly formatVersion: typeof APP_RELEASE_FORMAT_VERSION;
    readonly appId: string;
    readonly version: string;
    readonly runtimeBaseline: string;
    readonly ui: PlatformUiExtensionDescriptor;
    readonly runtime: readonly RuntimeContributionDescriptor[];
    readonly dataDependencies: readonly DataDependencyContract[];
    readonly permissions: readonly PermissionDeclaration[];
}
export type AppReleaseState = 'draft' | 'quarantined' | 'validating' | 'ready-for-review' | 'published' | 'deprecated' | 'revoked' | 'rejected';
export type AppInstallationState = 'configuring' | 'validating' | 'enabled' | 'disabled' | 'needs-attention' | 'upgrading' | 'upgrade-failed';
