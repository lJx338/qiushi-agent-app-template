/**
 * Platform-owned identifiers intentionally exclude the upstream DSH session
 * identifier.  They are safe to return to a browser after BFF authorization.
 */
export interface ConversationRef {
    readonly conversationId: string;
    readonly status: 'active' | 'completed' | 'cancelled' | 'failed';
    readonly cursor: number;
}
export interface ConversationEvent {
    readonly eventId: string;
    readonly cursor: number;
    readonly type: 'assistant.delta' | 'tool.started' | 'tool.completed' | 'turn.completed' | 'turn.failed' | 'turn.cancelled';
    readonly occurredAt: string;
    readonly data: Readonly<Record<string, unknown>>;
}
/** Trusted scope created only after the BFF has re-authorized an action. */
export interface RuntimeScope {
    readonly tenantId: string;
    readonly actorId: string;
    readonly workspaceId: string;
    readonly installationId: string;
    readonly authEpoch: string;
}
export interface QuoteDraftInput {
    readonly customerId: string;
    readonly title: string;
    readonly unitPriceMinor: string;
    readonly quantity: number;
}
export interface QuoteDraftResult {
    readonly quoteId: string;
    readonly version: number;
    readonly customerId: string;
    readonly title: string;
    readonly totalMinor: string;
    readonly currency: 'CNY';
}
/** The shared UI and DSH business boundary; caller fields never carry actor/tenant. */
export interface QuoteBusinessPort {
    createDraft(scope: RuntimeScope, input: QuoteDraftInput, idempotencyKey: string, signal: AbortSignal): Promise<QuoteDraftResult>;
    getDraft(scope: RuntimeScope, quoteId: string): Promise<QuoteDraftResult | null>;
}
