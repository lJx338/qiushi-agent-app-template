export declare const PLATFORM_UI_API_VERSION: "qiushi.ui.v1";
export type PlatformPageKind = 'form' | 'table' | 'conversation' | 'mixed';
/** Trusted, reviewed UI contribution loaded by the platform React host. */
export interface PlatformUiExtensionDescriptor {
    readonly apiVersion: typeof PLATFORM_UI_API_VERSION;
    readonly entry: string;
    readonly routeSegment: string;
    readonly pageKind: PlatformPageKind;
    readonly requiredHostComponents: readonly string[];
}
export interface PlatformUiBridgeCapabilities {
    readonly conversation: boolean;
    readonly data: readonly string[];
    readonly actions: readonly string[];
}
