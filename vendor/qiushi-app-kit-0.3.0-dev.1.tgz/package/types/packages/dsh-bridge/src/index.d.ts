import type { Context } from '@deepseek-ai/cordis';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import { type AppDefinition, type Json } from '../../app-sdk/src/index.ts';
import type { QuoteBusinessPort, RuntimeScope } from '../../control-contracts/src/index.ts';
/** Production provider is NOT implemented by the development executor. */
export interface BusinessProvider {
    execute(app: AppDefinition, actionId: string, input: Json, execution: ToolRunContext): Promise<Json>;
}
/**
 * The native DSH tool provider and the platform UI both call QuoteBusinessPort.
 * Scope comes from the cell established by the runtime manager; never from a
 * tool argument.  This factory is intentionally narrow to the I3 quote app.
 */
export declare function createQuoteBusinessProvider(scope: RuntimeScope, quotes: QuoteBusinessPort): BusinessProvider;
declare module '@deepseek-ai/cordis' {
    interface Context {
        qsBusiness: BusinessProvider;
    }
}
/** Register raw DSH tools; DSH owns registration lifetime and native execution. */
export declare function registerDshApp(ctx: Context, app: AppDefinition): void;
